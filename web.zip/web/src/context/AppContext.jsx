import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { ACHIEVEMENTS } from '../data/mockData.js'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [user, setUser]           = useState(null)
  const [darkMode, setDarkMode]   = useState(false)
  const [ttsVoiceIndex, setTtsVoiceIndex] = useState(0)

  const [notifications, setNotifications] = useState([
    { id: 'n1', type: 'partner_request', from: 'Kwame O.', message: 'wants you to read Trader 2 in "The Lantern of Kumasi"', roomId: 'r1', read: false, ts: Date.now() - 120000 },
    { id: 'n2', type: 'book_update',     from: 'Efua Mensah', message: 'just uploaded a new chapter of "Whispers Under the Baobab"', bookId: 'sb1', read: false, ts: Date.now() - 600000 }
  ])

  // Books the user has purchased  { [bookId]: { purchasedAt, price, title, authorId } }
  const [purchases, setPurchases] = useState({})

  // Books currently lent OUT by this user
  // [{ lendId, bookId, bookTitle, toFriendId, toFriendName, toFriendAvatar, expiresAt, lentAt }]
  const [lentBooks, setLentBooks] = useState([])

  // Books lent TO this user (borrowed)
  // [{ lendId, bookId, bookTitle, fromName, expiresAt, lentAt, fileUrl? }]
  const [borrowedBooks, setBorrowedBooks] = useState([
    {
      lendId: 'demo_lend',
      bookId: 'sb4',
      bookTitle: 'Kente Threads: Stories in Pattern',
      bookEmoji: '🎨',
      fromName: 'Ama Agyei',
      expiresAt: Date.now() + 2 * 60 * 60 * 1000, // 2 hours from now (demo)
      lentAt: Date.now() - 60 * 60 * 1000
    }
  ])

  // Uploaded books (user is author) [{ id, title, coverEmoji, fileUrl, level, genre, price, format, description, publishedAt, chapters, lendable, lendDays, sales, readers }]
  const [myPublishedBooks, setMyPublishedBooks] = useState([])

  // Collaborative reading sessions from uploaded PDFs
  // [{ sessionId, bookId, bookTitle, fileUrl, ownerId, participants, invitedEmails, startedAt }]
  const [readingSessions, setReadingSessions] = useState([])

  const [subscribedBooks, setSubscribedBooks] = useState(['sb2'])
  const [followedWriters, setFollowedWriters]  = useState([])
  const [myRooms,   setMyRooms]    = useState([])
  const [progress,  setProgress]   = useState({})
  const [bookmarks, setBookmarks]  = useState({})
  const [history,   setHistory]    = useState([])
  const [earned,    setEarned]     = useState(new Set(['first_room', 'partner']))
  const [xp,        setXp]         = useState(25)
  const [reviews,   setReviews]    = useState({})

  // ── Expiry ticker: remove expired borrows every 10s ───────────────────
  useEffect(() => {
    const t = setInterval(() => {
      const now = Date.now()
      setBorrowedBooks(bs => bs.filter(b => b.expiresAt > now))
      setLentBooks(ls => ls.map(l => ({ ...l, expired: l.expiresAt <= now })))
    }, 10000)
    return () => clearInterval(t)
  }, [])

  // ── helpers ───────────────────────────────────────────────────────────
  const markRead    = useCallback(id => setNotifications(ns => ns.map(n => n.id === id ? { ...n, read: true } : n)), [])
  const markAllRead = useCallback(() => setNotifications(ns => ns.map(n => ({ ...n, read: true }))), [])
  const addNotification = useCallback(n =>
    setNotifications(ns => [{ ...n, id: 'n_' + Date.now(), read: false, ts: Date.now() }, ...ns]), [])

  const toggleSubscribe = useCallback(id =>
    setSubscribedBooks(bs => bs.includes(id) ? bs.filter(b => b !== id) : [...bs, id]), [])
  const toggleFollow = useCallback(id =>
    setFollowedWriters(ws => ws.includes(id) ? ws.filter(w => w !== id) : [...ws, id]), [])
  const joinRoom = useCallback(room =>
    setMyRooms(rs => rs.find(r => r.id === room.id) ? rs : [...rs, room]), [])

  // Purchase a book
  const purchaseBook = useCallback((book) => {
    setPurchases(p => ({
      ...p,
      [book.id]: { purchasedAt: Date.now(), price: book.price, title: book.title, authorId: book.authorId, bookEmoji: book.coverEmoji }
    }))
    addNotification({ type: 'purchase', from: 'EchoVerse Store', message: `You now own "${book.title}" — find it in My Books.` })
  }, [addNotification])

  // Lend a book to a friend
  const lendBook = useCallback((book, friend, durationMs) => {
    const lendId   = 'lend_' + Date.now()
    const expiresAt = Date.now() + durationMs
    setLentBooks(ls => [...ls, {
      lendId, bookId: book.id, bookTitle: book.title, bookEmoji: book.coverEmoji,
      toFriendId: friend.id, toFriendName: friend.name, toFriendAvatar: friend.avatar,
      expiresAt, lentAt: Date.now(), expired: false
    }])
    // Simulate the friend receiving the lend (in a real app this goes via backend)
    setBorrowedBooks(bs => [...bs, {
      lendId, bookId: book.id, bookTitle: book.title, bookEmoji: book.coverEmoji,
      fromName: user?.name || 'You', expiresAt, lentAt: Date.now()
    }])
    addNotification({ type: 'lend', from: 'You', message: `Lent "${book.title}" to ${friend.name} — expires in ${formatMs(durationMs)}.` })
  }, [user, addNotification])

  // Revoke a lend immediately
  const revokeLend = useCallback((lendId) => {
    setLentBooks(ls => ls.filter(l => l.lendId !== lendId))
    setBorrowedBooks(bs => bs.filter(b => b.lendId !== lendId))
    addNotification({ type: 'lend', from: 'You', message: 'Book access revoked from friend.' })
  }, [addNotification])

  // Publish a new book (writer upload)
  const publishBook = useCallback((bookData) => {
    const newBook = { ...bookData, id: 'pub_' + Date.now(), publishedAt: Date.now(), sales: 0, readers: 0 }
    setMyPublishedBooks(bs => [...bs, newBook])
    earnAchievement('writer')
    addNotification({ type: 'publish', from: 'EchoVerse', message: `"${bookData.title}" is now live in the store!` })
    return newBook
  }, [addNotification])

  // Start a collaborative reading session from an uploaded book
  const startReadingSession = useCallback((book, invitedFriends) => {
    const session = {
      sessionId: 'sess_' + Date.now(),
      bookId: book.id, bookTitle: book.title, bookEmoji: book.coverEmoji,
      fileUrl: book.fileUrl, ownerId: user?.name,
      participants: [user?.name],
      invitedEmails: invitedFriends.map(f => f.email),
      startedAt: Date.now()
    }
    setReadingSessions(ss => [...ss, session])
    invitedFriends.forEach(f =>
      addNotification({ type: 'session_invite', from: user?.name || 'A reader', message: `invited you to read "${book.title}" together` })
    )
    return session
  }, [user, addNotification])

  const earnAchievement = useCallback((id) => {
    const ach = ACHIEVEMENTS.find(a => a.id === id)
    if (!ach) return
    setEarned(e => { const n = new Set(e); n.add(id); return n })
    setXp(x => x + ach.xp)
    addNotification({ type: 'achievement', from: 'EchoVerse', message: `You earned "${ach.name}" ${ach.emoji} (+${ach.xp} XP)` })
  }, [addNotification])

  const updateProgress = useCallback((storyId, linesRead, total, character, title) => {
    setProgress(p => {
      const prev = p[storyId] || {}
      const completed = linesRead >= total
      if (completed && !prev.completed) {
        setTimeout(() => {
          setHistory(h => [{ storyId, title, completedAt: new Date().toISOString(), character }, ...h])
          earnAchievement('first_read')
        }, 0)
      }
      return { ...p, [storyId]: { linesRead, completed, character } }
    })
  }, [earnAchievement])

  const setBookmark = useCallback((storyId, lineIndex) =>
    setBookmarks(b => ({ ...b, [storyId]: lineIndex })), [])

  const addReview = useCallback((bookId, review) =>
    setReviews(r => ({ ...r, [bookId]: [review, ...(r[bookId] || [])] })), [])

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <AppContext.Provider value={{
      user, setUser, darkMode, setDarkMode,
      ttsVoiceIndex, setTtsVoiceIndex,
      notifications, markRead, markAllRead, addNotification, unreadCount,
      purchases, purchaseBook,
      lentBooks, borrowedBooks, lendBook, revokeLend,
      myPublishedBooks, publishBook, readingSessions, startReadingSession,
      subscribedBooks, toggleSubscribe,
      followedWriters, toggleFollow,
      myRooms, joinRoom,
      progress, updateProgress,
      bookmarks, setBookmark,
      history, earned, earnAchievement, xp,
      totalXpLevel: Math.floor(xp / 50) + 1,
      reviews, addReview,
    }}>
      {children}
    </AppContext.Provider>
  )
}

function formatMs(ms) {
  if (ms < 3600000) return `${Math.round(ms / 60000)} minutes`
  if (ms < 86400000) return `${Math.round(ms / 3600000)} hour${ms > 7200000 ? 's' : ''}`
  return `${Math.round(ms / 86400000)} day${ms > 172800000 ? 's' : ''}`
}

export const useApp = () => useContext(AppContext)
