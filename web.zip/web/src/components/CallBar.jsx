import { useState } from 'react'

// This bar is intentionally small, fixed to a corner, and dismissible/minimizable
// so a live voice/video call never covers or interrupts the reading text itself.
export default function CallBar({ roomTitle, participants = [] }) {
  const [minimized, setMinimized] = useState(false)
  const [muted, setMuted] = useState(false)
  const [active, setActive] = useState(true)

  if (!active) return null

  if (minimized) {
    return (
      <div className="call-bar minimized" onClick={() => setMinimized(false)} title="Reopen call">
        🎙️
      </div>
    )
  }

  return (
    <div className="call-bar">
      <div style={{ fontWeight: 'bold' }}>🎙️ Live call · {roomTitle}</div>
      <div style={{ fontSize: 11, opacity: 0.8 }}>{participants.length} on call</div>
      <div className="row">
        <div className="controls">
          <button className="mute" onClick={() => setMuted(m => !m)}>{muted ? 'Unmute' : 'Mute'}</button>
          <button onClick={() => setMinimized(true)}>Minimize</button>
        </div>
        <button className="leave" onClick={() => setActive(false)}>Leave</button>
      </div>
    </div>
  )
}
