// Lightweight PDF viewer using the browser's native PDF rendering via <iframe>.
// Works for any uploaded file (passed as an object URL) or a remote PDF URL.
export default function PdfViewer({ src }) {
  if (!src) {
    return <div className="card">No PDF selected yet.</div>
  }
  return <iframe className="pdf-frame" src={src} title="PDF reader" />
}
