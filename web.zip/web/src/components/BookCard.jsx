export default function BookCard({ book, onToggleSubscribe }) {
  return (
    <div className="card">
      <span className="tag">{book.level}</span>
      <span className="tag">{book.format}</span>
      <h3>{book.title}</h3>
      <div style={{ fontSize: 13, color: 'var(--muted)' }}>by {book.writer}</div>
      <p>{book.description}</p>
      <button
        className={book.subscribed ? 'btn secondary' : 'btn'}
        onClick={() => onToggleSubscribe(book.id)}
      >
        {book.subscribed ? 'Subscribed ✓' : 'Subscribe'}
      </button>
    </div>
  )
}
