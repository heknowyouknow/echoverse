import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { LEVELS } from '../data/mockData.js'

const AVATARS = ['🦋', '📖', '🌿', '🌙', '🎶', '🕊️', '🌺', '🦚']

export default function Onboarding() {
  const { setUser } = useApp()
  const [step, setStep] = useState(1)
  const [name, setName] = useState('')
  const [level, setLevel] = useState('')
  const [avatar, setAvatar] = useState(AVATARS[0])
  const [role, setRole] = useState('')

  function finish() {
    if (!name || !level || !role) return
    setUser({ name, level, avatar, role })
  }

  return (
    <div style={overlay}>
      <div style={modal}>
        {step === 1 && (
          <>
            <div style={logo}>📖</div>
            <h2 style={{ marginTop: 0 }}>Welcome to EchoVerse</h2>
            <p style={{ color: 'var(--muted)' }}>A place to read poetry and stories out loud, together.</p>
            <label>Your name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Ama Agyei" />
            <label>Choose your avatar</label>
            <div style={pillRow}>
              {AVATARS.map(a => (
                <span
                  key={a}
                  onClick={() => setAvatar(a)}
                  style={{ ...avatarBtn, background: avatar === a ? 'var(--accent-soft)' : 'white', border: avatar === a ? '2px solid var(--accent)' : '1px solid var(--accent-soft)' }}
                >
                  {a}
                </span>
              ))}
            </div>
            <button className="btn" style={{ width: '100%', marginTop: 8 }} disabled={!name} onClick={() => setStep(2)}>Next →</button>
          </>
        )}

        {step === 2 && (
          <>
            <h2>What's your reading level?</h2>
            <div style={pillRow}>
              {LEVELS.map(l => (
                <span
                  key={l}
                  className={`pill ${level === l ? 'active' : ''}`}
                  onClick={() => setLevel(l)}
                >
                  {l}
                </span>
              ))}
            </div>
            <h3>Are you joining as…</h3>
            <div style={pillRow}>
              {['Reader', 'Writer', 'Both'].map(r => (
                <span key={r} className={`pill ${role === r ? 'active' : ''}`} onClick={() => setRole(r)}>{r}</span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              <button className="btn ghost" onClick={() => setStep(1)}>← Back</button>
              <button className="btn" style={{ flex: 1 }} disabled={!level || !role} onClick={finish}>
                Enter EchoVerse {avatar}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

const overlay = {
  position: 'fixed', inset: 0,
  background: 'rgba(43,36,24,0.82)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  zIndex: 200
}
const modal = {
  background: 'var(--paper)',
  borderRadius: 16,
  padding: '32px 28px',
  maxWidth: 400,
  width: '92%',
  boxShadow: '0 12px 40px rgba(0,0,0,0.35)'
}
const logo = { fontSize: 48, textAlign: 'center', marginBottom: 8 }
const pillRow = { display: 'flex', flexWrap: 'wrap', gap: 8, margin: '10px 0' }
const avatarBtn = { fontSize: 26, padding: '6px 10px', borderRadius: 10, cursor: 'pointer' }
