import { useState, useEffect } from 'react'

export function useCountdown(expiresAt) {
  const [remaining, setRemaining] = useState(Math.max(0, expiresAt - Date.now()))

  useEffect(() => {
    const tick = () => setRemaining(Math.max(0, expiresAt - Date.now()))
    tick()
    const t = setInterval(tick, 1000)
    return () => clearInterval(t)
  }, [expiresAt])

  return remaining
}

// Returns a formatted string like "2d 4h 30m 10s"
export function formatRemaining(ms) {
  if (ms <= 0) return 'Expired'
  const s = Math.floor(ms / 1000)
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  if (d > 0) return `${d}d ${h}h ${m}m`
  if (h > 0) return `${h}h ${m}m ${sec}s`
  if (m > 0) return `${m}m ${sec}s`
  return `${sec}s`
}

// Urgency colour based on time left
export function urgencyColor(ms) {
  if (ms <= 0)              return '#8c2c2c'   // red — expired
  if (ms < 3600000)         return '#c0392b'   // red — under 1 hour
  if (ms < 86400000)        return '#e67e22'   // orange — under 1 day
  return 'var(--good)'                         // green — plenty of time
}

export default function Countdown({ expiresAt, prefix = 'Expires in', style = {} }) {
  const remaining = useCountdown(expiresAt)
  const color = urgencyColor(remaining)
  const text  = formatRemaining(remaining)

  return (
    <span style={{ color, fontWeight: 'bold', fontSize: 13, ...style }}>
      {remaining <= 0 ? '⛔ Expired' : `⏱ ${prefix}: ${text}`}
    </span>
  )
}
