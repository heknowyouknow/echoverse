import { useApp } from '../context/AppContext.jsx'
import { useNavigate } from 'react-router-dom'

function timeAgo(ts) {
  const diff = Date.now() - ts
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  return `${Math.floor(diff / 3600000)}h ago`
}

export default function NotificationsPanel({ onClose }) {
  const { notifications, markRead, markAllRead } = useApp()
  const navigate = useNavigate()

  function handleClick(n) {
    markRead(n.id)
    onClose()
    if (n.type === 'partner_request') navigate(`/rooms/${n.roomId}`)
    if (n.type === 'book_update') navigate('/library')
  }

  return (
    <div style={panel}>
      <div style={header}>
        <strong>Notifications</strong>
        <span onClick={markAllRead} style={markAllBtn}>Mark all read</span>
      </div>
      {notifications.length === 0 && <p style={{ color: 'var(--muted)', padding: '12px' }}>No notifications yet.</p>}
      {notifications.map(n => (
        <div key={n.id} style={{ ...item, background: n.read ? 'transparent' : '#fff8f0' }} onClick={() => handleClick(n)}>
          <div style={{ fontSize: 22, marginRight: 10 }}>
            {n.type === 'partner_request' ? '🎭' : '📚'}
          </div>
          <div style={{ flex: 1 }}>
            <strong>{n.from}</strong> {n.message}
            <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{timeAgo(n.ts)}</div>
          </div>
          {!n.read && <span style={dot} />}
        </div>
      ))}
    </div>
  )
}

const panel = {
  position: 'absolute',
  top: '100%',
  right: 0,
  width: 320,
  background: 'var(--paper)',
  border: '1px solid var(--accent-soft)',
  borderRadius: 12,
  boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
  zIndex: 100,
  overflow: 'hidden'
}
const header = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '12px 16px',
  borderBottom: '1px solid var(--accent-soft)',
  background: 'white'
}
const markAllBtn = {
  fontSize: 12,
  color: 'var(--accent)',
  cursor: 'pointer'
}
const item = {
  display: 'flex',
  alignItems: 'flex-start',
  padding: '12px 14px',
  borderBottom: '1px solid var(--accent-soft)',
  cursor: 'pointer',
  fontSize: 13
}
const dot = {
  width: 8, height: 8,
  borderRadius: '50%',
  background: 'var(--accent)',
  marginTop: 4, marginLeft: 6,
  flexShrink: 0
}
