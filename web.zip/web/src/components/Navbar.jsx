import { useState, useRef, useEffect } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import NotificationsPanel from './NotificationsPanel.jsx'

export default function Navbar() {
  const { user, unreadCount, purchases } = useApp()
  const [showNotifs, setShowNotifs] = useState(false)
  const [menuOpen,   setMenuOpen]   = useState(false)
  const bellRef = useRef(null)
  const navigate = useNavigate()
  const { pathname } = useLocation()

  const ownedCount = Object.keys(purchases).length

  useEffect(() => {
    function handler(e) {
      if (bellRef.current && !bellRef.current.contains(e.target)) setShowNotifs(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // Close mobile menu on nav
  useEffect(() => setMenuOpen(false), [pathname])

  const nav = [
    { to: '/explore',  label: 'Explore' },
    { to: '/rooms',    label: 'Rooms' },
    { to: '/store',    label: '🛒 Store' },
    { to: '/mybooks',  label: `My Books${ownedCount ? ` (${ownedCount})` : ''}` },
    { to: '/library',  label: 'Library' },
    { to: '/create',   label: 'Request' },
    { to: '/upload',   label: '+ Upload' },
    { to: '/author-dashboard', label: '📊 Dashboard' },
  ]

  return (
    <div className="navbar" style={{ flexWrap: 'wrap', gap: 8 }}>
      <Link to="/" style={{ textDecoration: 'none' }}>
        <div className="brand">📖 EchoVerse</div>
      </Link>

      {/* Hamburger for small screens */}
      <button
        onClick={() => setMenuOpen(m => !m)}
        style={{ display: 'none', background: 'none', border: 'none', color: 'white', fontSize: 22, cursor: 'pointer' }}
        className="hamburger"
      >☰</button>

      <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
        {nav.map(n => (
          <Link key={n.to} to={n.to} style={{ color: pathname === n.to ? '#e8d9c5' : undefined, fontWeight: pathname === n.to ? 'bold' : undefined }}>
            {n.label}
          </Link>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginLeft: 'auto' }}>
        {/* Bell */}
        <div ref={bellRef} style={{ position: 'relative' }}>
          <button onClick={() => setShowNotifs(s => !s)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'white', fontSize: 18, padding: '2px 6px', position: 'relative' }}>
            🔔
            {unreadCount > 0 && (
              <span style={{ position: 'absolute', top: -2, right: -2, background: 'var(--accent)', color: 'white', borderRadius: '50%', fontSize: 10, width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {unreadCount}
              </span>
            )}
          </button>
          {showNotifs && <NotificationsPanel onClose={() => setShowNotifs(false)} />}
        </div>

        {/* Avatar */}
        {user && (
          <div onClick={() => navigate('/dashboard')} style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 18, marginLeft: 4 }} title={user.name}>
            {user.avatar}
          </div>
        )}
      </div>
    </div>
  )
}
