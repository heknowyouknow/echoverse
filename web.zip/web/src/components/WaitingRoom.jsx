import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import { READING_ROOMS, STORY_LIBRARY } from '../data/mockData.js'

const MATCH_STEPS = [
  'Searching for available readers…',
  'Found 3 readers online in your level…',
  'Checking availability…',
  'Sending invitations…',
  'A reader accepted! Setting up the room…',
]

export default function WaitingRoom({ storyId, characterCount, onCancel }) {
  const navigate = useNavigate()
  const { addNotification, earnAchievement } = useApp()
  const [step, setStep] = useState(0)
  const [dots, setDots] = useState(0)
  const [matched, setMatched] = useState(false)
  const story = STORY_LIBRARY.find(s => s.id === storyId)

  // Animate dots
  useEffect(() => {
    const d = setInterval(() => setDots(n => (n + 1) % 4), 400)
    return () => clearInterval(d)
  }, [])

  // Progress through match steps
  useEffect(() => {
    if (step >= MATCH_STEPS.length - 1) {
      setTimeout(() => {
        setMatched(true)
        addNotification({
          type: 'partner_request',
          from: 'System',
          message: `A reader matched for your "${story?.title}" room!`,
          roomId: 'r1'
        })
        earnAchievement('partner')
      }, 700)
      return
    }
    const delay = step === 0 ? 800 : step === 1 ? 1000 : step === 2 ? 600 : 1400
    const t = setTimeout(() => setStep(s => s + 1), delay)
    return () => clearTimeout(t)
  }, [step])

  return (
    <div style={overlay}>
      <div style={modal}>
        {!matched ? (
          <>
            <div style={{ fontSize: 48, textAlign: 'center', marginBottom: 12 }}>🔍</div>
            <h2 style={{ textAlign: 'center', marginTop: 0 }}>
              Finding {characterCount - 1} reader{characterCount > 2 ? 's' : ''}…
            </h2>
            {story && (
              <div className="card" style={{ textAlign: 'center', marginBottom: 16 }}>
                <span style={{ fontSize: 28 }}>{story.coverEmoji}</span>
                <div style={{ fontWeight: 'bold', marginTop: 4 }}>{story.title}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>{characterCount} characters</div>
              </div>
            )}

            {/* Step progress */}
            <div style={{ marginBottom: 16 }}>
              {MATCH_STEPS.map((msg, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, opacity: i <= step ? 1 : 0.3, transition: 'opacity 0.3s' }}>
                  <span style={{ fontSize: 14, color: i < step ? 'var(--good)' : i === step ? 'var(--accent)' : 'var(--muted)' }}>
                    {i < step ? '✓' : i === step ? '◉' : '○'}
                  </span>
                  <span style={{ fontSize: 13, color: i === step ? 'var(--ink)' : 'var(--muted)' }}>
                    {msg}{i === step ? '.'.repeat(dots) : ''}
                  </span>
                </div>
              ))}
            </div>

            <button className="btn ghost" onClick={onCancel} style={{ width: '100%' }}>Cancel search</button>
          </>
        ) : (
          <>
            <div style={{ fontSize: 56, textAlign: 'center' }}>🎭</div>
            <h2 style={{ textAlign: 'center' }}>Match found!</h2>
            <p style={{ textAlign: 'center', color: 'var(--muted)' }}>
              A reader has accepted the invitation for <strong>{story?.title}</strong>. Your reading room is ready.
            </p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn secondary" onClick={onCancel} style={{ flex: 1 }}>Not now</button>
              <button className="btn" onClick={() => { onCancel(); navigate('/rooms/r1') }} style={{ flex: 2 }}>
                Enter room →
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

const overlay = {
  position: 'fixed', inset: 0,
  background: 'rgba(43,36,24,0.78)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  zIndex: 200
}
const modal = {
  background: 'var(--paper)',
  borderRadius: 16, padding: '28px 24px',
  maxWidth: 380, width: '92%',
  boxShadow: '0 12px 40px rgba(0,0,0,0.3)'
}
