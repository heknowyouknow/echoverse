import { useState, useEffect } from 'react'
import { MOCK_FRIENDS, LEND_DURATIONS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

export default function LendModal({ book, onClose }) {
  const { lendBook } = useApp()
  const [friend,   setFriend]   = useState(null)
  const [duration, setDuration] = useState(LEND_DURATIONS[1]) // default 24h
  const [step,     setStep]     = useState('pick') // 'pick' | 'confirm' | 'sent'

  function send() {
    lendBook(book, friend, duration.ms)
    setStep('sent')
  }

  return (
    <div style={overlay} onClick={onClose}>
      <div style={modal} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
          <h2 style={{ margin: 0 }}>🤝 Lend "{book.title}"</h2>
          <button className="btn ghost" onClick={onClose}>✕</button>
        </div>

        {step === 'pick' && (
          <>
            <p style={{ color: 'var(--muted)', fontSize: 13 }}>
              Choose a friend and how long they can access this book. When the time is up, access is automatically removed — they won't be able to open it.
            </p>

            <label>Choose a friend</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {MOCK_FRIENDS.map(f => (
                <div
                  key={f.id}
                  onClick={() => setFriend(f)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '10px 14px', borderRadius: 8, cursor: 'pointer',
                    border: `2px solid ${friend?.id === f.id ? 'var(--accent)' : 'var(--accent-soft)'}`,
                    background: friend?.id === f.id ? '#fff8f4' : 'white'
                  }}
                >
                  <span style={{ fontSize: 26 }}>{f.avatar}</span>
                  <div>
                    <div style={{ fontWeight: 'bold' }}>{f.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>{f.email}</div>
                  </div>
                  {friend?.id === f.id && <span style={{ marginLeft: 'auto', color: 'var(--accent)' }}>✓</span>}
                </div>
              ))}
            </div>

            <label>Lending period</label>
            <div className="pill-row" style={{ marginBottom: 20 }}>
              {LEND_DURATIONS.map(d => (
                <span
                  key={d.label}
                  className={`pill ${duration.label === d.label ? 'active' : ''}`}
                  onClick={() => setDuration(d)}
                >
                  {d.label}
                </span>
              ))}
            </div>

            {book.lendDays && (
              <p style={{ fontSize: 12, color: 'var(--muted)', background: 'var(--accent-soft)', borderRadius: 6, padding: '8px 10px' }}>
                ℹ️ The author of this book allows lending for up to {book.lendDays} day{book.lendDays > 1 ? 's' : ''} at a time.
              </p>
            )}

            <button className="btn" disabled={!friend} style={{ width: '100%', marginTop: 8 }} onClick={() => setStep('confirm')}>
              Continue →
            </button>
          </>
        )}

        {step === 'confirm' && friend && (
          <>
            <div style={{ background: 'var(--accent-soft)', borderRadius: 10, padding: 16, marginBottom: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                <span style={{ fontSize: 36 }}>{book.coverEmoji}</span>
                <div>
                  <div style={{ fontWeight: 'bold' }}>{book.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>by {book.author}</div>
                </div>
              </div>
              <div style={{ borderTop: '1px solid var(--accent-soft)', paddingTop: 10, display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13 }}>
                <Row label="Lending to" value={`${friend.avatar} ${friend.name}`} />
                <Row label="Access duration" value={duration.label} />
                <Row label="Access expires" value={new Date(Date.now() + duration.ms).toLocaleString()} />
                <Row label="After expiry" value="Friend loses access immediately" />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn ghost" onClick={() => setStep('pick')} style={{ flex: 1 }}>← Back</button>
              <button className="btn" onClick={send} style={{ flex: 2 }}>Send lend to {friend.name}</button>
            </div>
          </>
        )}

        {step === 'sent' && (
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <div style={{ fontSize: 52 }}>🎉</div>
            <h3>Lend sent!</h3>
            <p style={{ color: 'var(--muted)' }}>
              {friend?.avatar} <strong>{friend?.name}</strong> can now read "{book.title}" for <strong>{duration.label}</strong>.
              After that, access is automatically removed.
            </p>
            <p style={{ fontSize: 12, color: 'var(--muted)' }}>
              You can revoke access early from <strong>My Books → Active Lends</strong>.
            </p>
            <button className="btn" onClick={onClose} style={{ marginTop: 8 }}>Done</button>
          </div>
        )}
      </div>
    </div>
  )
}

function Row({ label, value }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
      <span style={{ color: 'var(--muted)' }}>{label}</span>
      <span style={{ fontWeight: 'bold', textAlign: 'right' }}>{value}</span>
    </div>
  )
}

const overlay = { position: 'fixed', inset: 0, background: 'rgba(43,36,24,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }
const modal = { background: 'var(--paper)', borderRadius: 16, padding: '24px', maxWidth: 440, width: '93%', maxHeight: '92vh', overflowY: 'auto', boxShadow: '0 12px 40px rgba(0,0,0,0.35)' }
