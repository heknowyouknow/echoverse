import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { WRITER_BOOKS, WRITERS, SAMPLE_REVIEWS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

function StarPicker({ value, onChange }) {
  return (
    <div style={{ display: 'flex', gap: 4, fontSize: 24, cursor: 'pointer' }}>
      {[1, 2, 3, 4, 5].map(n => (
        <span key={n} onClick={() => onChange(n)} style={{ color: n <= value ? '#f5a623' : 'var(--accent-soft)' }}>★</span>
      ))}
    </div>
  )
}

export default function BookDetail() {
  const { id } = useParams()
  const { subscribedBooks, toggleSubscribe, reviews, addReview, user, earnAchievement } = useApp()
  const book = WRITER_BOOKS.find(b => b.id === id)
  const writer = book ? WRITERS.find(w => w.bookIds.includes(id)) : null
  const subbed = subscribedBooks.includes(id)

  const [rating, setRating] = useState(0)
  const [reviewText, setReviewText] = useState('')
  const [submitted, setSubmitted] = useState(false)

  if (!book) return <div className="card">Book not found. <Link to="/library">Browse library</Link>.</div>

  const allReviews = [...(SAMPLE_REVIEWS[id] || []), ...(reviews[id] || [])]
  const avgRating = allReviews.length
    ? (allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length).toFixed(1)
    : null

  function submitReview(e) {
    e.preventDefault()
    if (!rating || !reviewText.trim()) return
    addReview(id, {
      id: 'rv_' + Date.now(),
      user: user?.name || 'Anonymous',
      avatar: user?.avatar || '📖',
      rating,
      text: reviewText.trim(),
      date: new Date().toISOString().slice(0, 10)
    })
    earnAchievement('review_writer')
    setSubmitted(true)
    setRating(0)
    setReviewText('')
  }

  return (
    <div>
      {/* Hero */}
      <div className="card" style={{ display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <div style={{ fontSize: 64 }}>{book.coverEmoji}</div>
        <div style={{ flex: 1 }}>
          <span className="tag">{book.level}</span>
          <span className="tag">{book.genre}</span>
          <span className="tag">{book.format}</span>
          <h1 style={{ margin: '8px 0 2px' }}>{book.title}</h1>
          {writer && (
            <div style={{ marginBottom: 8 }}>
              <Link to={`/writers/${writer.id}`} style={{ color: 'var(--muted)', fontSize: 13 }}>
                {writer.avatar} {writer.name}
              </Link>
            </div>
          )}
          <p style={{ margin: '0 0 10px' }}>{book.description}</p>
          <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
            {book.chapters} chapters · {book.price}
            {avgRating && <span style={{ marginLeft: 10 }}>⭐ {avgRating} ({allReviews.length} review{allReviews.length !== 1 ? 's' : ''})</span>}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className={subbed ? 'btn secondary' : 'btn'} onClick={() => toggleSubscribe(id)}>
              {subbed ? '✓ Subscribed' : 'Subscribe to read'}
            </button>
            {subbed && <Link to="/library"><button className="btn ghost">Open in Library</button></Link>}
          </div>
        </div>
      </div>

      {/* Reviews */}
      <h2>Reviews</h2>
      {allReviews.length === 0 && <p style={{ color: 'var(--muted)' }}>No reviews yet. Be the first!</p>}
      {allReviews.map(r => (
        <div className="card" key={r.id} style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 20 }}>{r.avatar}</span>
              <strong>{r.user}</strong>
            </div>
            <div>
              <span style={{ color: '#f5a623' }}>{'★'.repeat(r.rating)}</span>
              <span style={{ color: 'var(--muted)', fontSize: 11, marginLeft: 6 }}>{r.date}</span>
            </div>
          </div>
          <p style={{ margin: 0, fontSize: 14 }}>{r.text}</p>
        </div>
      ))}

      {/* Write a review */}
      <div className="card">
        <h3 style={{ marginTop: 0 }}>Write a review</h3>
        {submitted ? (
          <p style={{ color: 'var(--good)' }}>✓ Review submitted! Thank you.</p>
        ) : (
          <form onSubmit={submitReview}>
            <label>Your rating</label>
            <StarPicker value={rating} onChange={setRating} />
            <label style={{ marginTop: 12, display: 'block' }}>Your review</label>
            <textarea
              value={reviewText}
              onChange={e => setReviewText(e.target.value)}
              rows={4}
              placeholder="What did you think of this book?"
            />
            <button className="btn" type="submit" disabled={!rating || !reviewText.trim()}>
              Submit review
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
