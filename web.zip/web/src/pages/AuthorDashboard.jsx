import { useState } from 'react'
import { Link } from 'react-router-dom'
import { STORE_BOOKS, AUTHOR_STATS, WRITERS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

// Mini bar-chart using divs (no extra libs needed)
function BarChart({ data, label, color = 'var(--accent)' }) {
  const max = Math.max(...data, 1)
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
  return (
    <div>
      <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>{label}</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'flex-end', height: 80 }}>
        {data.map((v, i) => (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
            <div style={{ fontSize: 10, color: 'var(--muted)' }}>{v}</div>
            <div style={{
              width: '100%', background: color, borderRadius: '3px 3px 0 0',
              height: `${Math.round((v / max) * 60)}px`, minHeight: 2,
              transition: 'height 0.4s'
            }} />
            <div style={{ fontSize: 9, color: 'var(--muted)' }}>{months[i]}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function AuthorDashboard() {
  const { user, myPublishedBooks } = useApp()
  // Demo: use w1 as the logged-in author, or the first writer
  const authorId = 'w1'
  const author = WRITERS.find(w => w.id === authorId)
  const stats  = AUTHOR_STATS[authorId]
  const myBooks = STORE_BOOKS.filter(b => b.authorId === authorId)
  const [activeBook, setActiveBook] = useState(null)

  const totalRevenue = stats.totalRevenue
  const thisMonth = stats.monthlyRevenue[stats.monthlyRevenue.length - 1]
  const lastMonth = stats.monthlyRevenue[stats.monthlyRevenue.length - 2]
  const revGrowth = Math.round(((thisMonth - lastMonth) / lastMonth) * 100)

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 52 }}>{author?.avatar}</span>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', align: 'center', gap: 10, flexWrap: 'wrap' }}>
            <h1 style={{ margin: 0 }}>{author?.name}</h1>
            <span style={{ background: '#e8f5e9', color: '#3f6b4a', fontSize: 12, padding: '3px 10px', borderRadius: 999, fontWeight: 'bold', alignSelf: 'center' }}>
              ✓ Verified Author
            </span>
          </div>
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>{author?.location} · {author?.followers} followers</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/upload"><button className="btn secondary">+ Upload new book</button></Link>
          <Link to={`/writers/${authorId}`}><button className="btn ghost">View public profile</button></Link>
        </div>
      </div>

      {/* KPI cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12, marginBottom: 24 }}>
        <KPI emoji="💰" label="Total revenue" value={`$${totalRevenue.toFixed(2)}`} />
        <KPI emoji="📈" label="This month" value={`$${thisMonth.toFixed(2)}`} sub={`${revGrowth > 0 ? '+' : ''}${revGrowth}% vs last month`} subColor={revGrowth >= 0 ? 'var(--good)' : '#c0392b'} />
        <KPI emoji="📚" label="Total sales" value={stats.totalSales} />
        <KPI emoji="👥" label="Unique readers" value={stats.readers} />
        <KPI emoji="⭐" label="Avg rating" value={stats.avgRating} />
        <KPI emoji="🤝" label="Active lends" value={stats.activeLends} />
      </div>

      {/* Revenue chart */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Revenue — last 6 months</h3>
        <BarChart data={stats.monthlyRevenue} label="Monthly revenue ($)" />
      </div>

      {/* Books table */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 style={{ margin: 0 }}>Your books</h3>
          <Link to="/upload"><button className="btn secondary" style={{ fontSize: 12 }}>+ New book</button></Link>
        </div>

        {[...myBooks, ...myPublishedBooks].map(b => (
          <div key={b.id} style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--accent-soft)', flexWrap: 'wrap' }}>
            <span style={{ fontSize: 32 }}>{b.coverEmoji}</span>
            <div style={{ flex: 1, minWidth: 180 }}>
              <div style={{ fontWeight: 'bold' }}>{b.title}</div>
              <div style={{ display: 'flex', gap: 6, marginTop: 3 }}>
                <span className="tag">{b.level}</span>
                <span className="tag">{b.genre}</span>
                <span className="tag">${b.price?.toFixed(2) ?? 'Free'}</span>
                {b.lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable</span>}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 24, fontSize: 13, textAlign: 'center' }}>
              <div><div style={{ fontWeight: 'bold', color: 'var(--accent)' }}>{b.sales ?? 0}</div><div style={{ color: 'var(--muted)', fontSize: 11 }}>sales</div></div>
              <div><div style={{ fontWeight: 'bold' }}>{b.reviewCount ?? 0}</div><div style={{ color: 'var(--muted)', fontSize: 11 }}>reviews</div></div>
              <div><div style={{ fontWeight: 'bold', color: 'var(--good)' }}>${((b.sales ?? 0) * (b.price ?? 0)).toFixed(2)}</div><div style={{ color: 'var(--muted)', fontSize: 11 }}>earned</div></div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <Link to={`/books/${b.id}`}><button className="btn ghost" style={{ fontSize: 12 }}>Reviews</button></Link>
              <button className="btn secondary" style={{ fontSize: 12 }} onClick={() => setActiveBook(b)}>Edit</button>
            </div>
          </div>
        ))}

        {myBooks.length === 0 && myPublishedBooks.length === 0 && (
          <div style={{ textAlign: 'center', padding: 24, color: 'var(--muted)' }}>
            No books published yet. <Link to="/upload">Upload your first book →</Link>
          </div>
        )}
      </div>

      {/* Edit modal (stub) */}
      {activeBook && (
        <div style={overlayStyle} onClick={() => setActiveBook(null)}>
          <div style={modalStyle} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ margin: 0 }}>Edit "{activeBook.title}"</h3>
              <button className="btn ghost" onClick={() => setActiveBook(null)}>✕</button>
            </div>
            <label>Price ($)</label>
            <input defaultValue={activeBook.price?.toFixed(2)} type="number" step="0.01" />
            <label>Allow lending</label>
            <div className="pill-row">
              <span className={`pill ${activeBook.lendable ? 'active' : ''}`}>Yes — lendable</span>
              <span className={`pill ${!activeBook.lendable ? 'active' : ''}`}>No — not lendable</span>
            </div>
            <label>Max lend duration (days)</label>
            <input defaultValue={activeBook.lendDays ?? 7} type="number" />
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button className="btn ghost" onClick={() => setActiveBook(null)} style={{ flex: 1 }}>Cancel</button>
              <button className="btn" onClick={() => setActiveBook(null)} style={{ flex: 2 }}>Save changes</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function KPI({ emoji, label, value, sub, subColor }) {
  return (
    <div className="card" style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 28 }}>{emoji}</div>
      <div style={{ fontSize: 22, fontWeight: 'bold', color: 'var(--accent)', margin: '4px 0 2px' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--muted)' }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: subColor || 'var(--muted)', marginTop: 2, fontWeight: 'bold' }}>{sub}</div>}
    </div>
  )
}

const overlayStyle = { position: 'fixed', inset: 0, background: 'rgba(43,36,24,0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }
const modalStyle = { background: 'var(--paper)', borderRadius: 14, padding: 24, maxWidth: 400, width: '92%', boxShadow: '0 12px 40px rgba(0,0,0,0.3)' }
