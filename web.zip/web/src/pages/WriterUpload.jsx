import { useState } from 'react'
import { Link } from 'react-router-dom'
import { LEVELS, GENRES } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'
import PdfViewer from '../components/PdfViewer.jsx'

const STEPS = ['Details', 'Pricing', 'Preview', 'Publish']

export default function WriterUpload() {
  const { publishBook, user } = useApp()
  const [step,    setStep]   = useState(0)
  const [file,    setFile]   = useState(null)
  const [fileUrl, setFileUrl] = useState(null)
  const [published, setPublished] = useState(null)

  // Form state
  const [title,       setTitle]       = useState('')
  const [author,      setAuthor]      = useState(user?.name || '')
  const [level,       setLevel]       = useState(LEVELS[1])
  const [genre,       setGenre]       = useState(GENRES[0])
  const [desc,        setDesc]        = useState('')
  const [chapters,    setChapters]    = useState(1)
  const [coverEmoji,  setCoverEmoji]  = useState('📖')
  const [isFree,      setIsFree]      = useState(false)
  const [price,       setPrice]       = useState('4.99')
  const [lendable,    setLendable]    = useState(true)
  const [lendDays,    setLendDays]    = useState(7)
  const [tags,        setTags]        = useState('')

  const COVER_OPTIONS = ['📖','🌳','🎵','🏮','🗺️','🎨','🌙','🦋','🌺','🕊️','🏔️','🌿','🎶','🌻','🐸']

  function handleFile(e) {
    const f = e.target.files[0]
    if (!f) return
    setFile(f)
    setFileUrl(URL.createObjectURL(f))
  }

  function handlePublish() {
    const book = publishBook({
      title, author, level, genre, description: desc,
      chapters: Number(chapters), coverEmoji,
      price: isFree ? 0 : parseFloat(price) || 0,
      format: file?.type === 'audio/mpeg' ? 'Audio' : 'PDF',
      lendable, lendDays: lendable ? Number(lendDays) : 0,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      fileUrl
    })
    setPublished(book)
  }

  const canAdvance = [
    title && author && desc && file,  // step 0
    true,                              // step 1 (pricing always valid)
    true,                              // step 2 (preview)
  ]

  if (published) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 20px' }}>
        <div style={{ fontSize: 64 }}>{published.coverEmoji}</div>
        <h1>🎉 "{published.title}" is live!</h1>
        <p style={{ color: 'var(--muted)', maxWidth: 440, margin: '0 auto 20px' }}>
          Your book is now listed in the EchoVerse store. Readers can discover, buy, and read it in-app.
        </p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link to="/author-dashboard"><button className="btn">📊 View in dashboard</button></Link>
          <Link to="/store"><button className="btn secondary">Browse store</button></Link>
          <button className="btn ghost" onClick={() => { setPublished(null); setStep(0); setFile(null); setFileUrl(null); setTitle('') }}>
            Upload another
          </button>
        </div>
      </div>
    )
  }

  return (
    <div>
      <h1>Upload a book</h1>

      {/* Step progress */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 28 }}>
        {STEPS.map((s, i) => (
          <div key={s} style={{ flex: 1, display: 'flex', alignItems: 'center' }}>
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: i <= step ? 'var(--accent)' : 'var(--accent-soft)',
                color: i <= step ? 'white' : 'var(--muted)', fontWeight: 'bold', fontSize: 14
              }}>
                {i < step ? '✓' : i + 1}
              </div>
              <div style={{ fontSize: 11, color: i <= step ? 'var(--accent)' : 'var(--muted)', marginTop: 4 }}>{s}</div>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{ height: 2, flex: 1, background: i < step ? 'var(--accent)' : 'var(--accent-soft)', margin: '0 4px', marginBottom: 18 }} />
            )}
          </div>
        ))}
      </div>

      {/* Step 0: Details */}
      {step === 0 && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Book details</h3>

          <label>Cover icon</label>
          <div className="pill-row" style={{ marginBottom: 14 }}>
            {COVER_OPTIONS.map(e => (
              <span key={e} onClick={() => setCoverEmoji(e)} style={{
                fontSize: 26, cursor: 'pointer', padding: '4px 8px', borderRadius: 8,
                background: coverEmoji === e ? 'var(--accent-soft)' : 'transparent',
                border: coverEmoji === e ? '2px solid var(--accent)' : '2px solid transparent'
              }}>{e}</span>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ flex: 2, minWidth: 180 }}>
              <label>Book title *</label>
              <input value={title} onChange={e => setTitle(e.target.value)} placeholder="My wonderful book" />
            </div>
            <div style={{ flex: 1, minWidth: 140 }}>
              <label>Author name *</label>
              <input value={author} onChange={e => setAuthor(e.target.value)} placeholder="Your name" />
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 140 }}>
              <label>Reading level *</label>
              <select value={level} onChange={e => setLevel(e.target.value)}>
                {LEVELS.map(l => <option key={l}>{l}</option>)}
              </select>
            </div>
            <div style={{ flex: 1, minWidth: 140 }}>
              <label>Genre *</label>
              <select value={genre} onChange={e => setGenre(e.target.value)}>
                {GENRES.map(g => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div style={{ flex: 1, minWidth: 100 }}>
              <label>Chapters</label>
              <input type="number" min={1} value={chapters} onChange={e => setChapters(e.target.value)} />
            </div>
          </div>

          <label>Description *</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="A short description for readers (will appear in the store)…" />

          <label>Tags (comma separated)</label>
          <input value={tags} onChange={e => setTags(e.target.value)} placeholder="e.g. Ghana, coming-of-age, nature" />

          <label>Book file * (PDF or text)</label>
          <input type="file" accept=".pdf,.txt" onChange={handleFile} style={{ marginBottom: 4 }} />
          {file && <div style={{ fontSize: 12, color: 'var(--good)', marginBottom: 10 }}>✓ {file.name} selected</div>}
        </div>
      )}

      {/* Step 1: Pricing */}
      {step === 1 && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Pricing & lending</h3>

          <label>Price</label>
          <div className="pill-row" style={{ marginBottom: 14 }}>
            <span className={`pill ${isFree ? 'active' : ''}`} onClick={() => setIsFree(true)}>Free</span>
            <span className={`pill ${!isFree ? 'active' : ''}`} onClick={() => setIsFree(false)}>Paid</span>
          </div>

          {!isFree && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <span style={{ fontSize: 20 }}>$</span>
              <input
                type="number" step="0.01" min="0.99" value={price}
                onChange={e => setPrice(e.target.value)}
                style={{ maxWidth: 120, margin: 0 }}
              />
              <span style={{ color: 'var(--muted)', fontSize: 13 }}>USD · EchoVerse takes 15% platform fee</span>
            </div>
          )}

          {!isFree && (
            <div style={{ background: 'var(--accent-soft)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Book price</span><span>${parseFloat(price || 0).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--muted)' }}>
                <span>Platform fee (15%)</span><span>−${(parseFloat(price || 0) * 0.15).toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', borderTop: '1px solid var(--accent-soft)', marginTop: 6, paddingTop: 6 }}>
                <span>You earn per sale</span><span style={{ color: 'var(--good)' }}>${(parseFloat(price || 0) * 0.85).toFixed(2)}</span>
              </div>
            </div>
          )}

          <label style={{ fontSize: 15, fontWeight: 'bold' }}>Book lending</label>
          <p style={{ color: 'var(--muted)', fontSize: 13, margin: '4px 0 12px' }}>
            Allow buyers to lend your book to a friend for a limited time. You control how long.
          </p>
          <div className="pill-row" style={{ marginBottom: 14 }}>
            <span className={`pill ${lendable ? 'active' : ''}`} onClick={() => setLendable(true)}>🤝 Allow lending</span>
            <span className={`pill ${!lendable ? 'active' : ''}`} onClick={() => setLendable(false)}>🔒 No lending</span>
          </div>
          {lendable && (
            <>
              <label>Maximum lend duration</label>
              <div className="pill-row">
                {[1, 3, 5, 7, 14].map(d => (
                  <span key={d} className={`pill ${lendDays === d ? 'active' : ''}`} onClick={() => setLendDays(d)}>
                    {d} day{d > 1 ? 's' : ''}
                  </span>
                ))}
              </div>
              <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
                After the lend period ends, the borrower's access is automatically removed and they cannot open the book.
              </p>
            </>
          )}
        </div>
      )}

      {/* Step 2: Preview */}
      {step === 2 && (
        <div>
          <div className="card" style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 16 }}>
            <div style={{ fontSize: 52, background: 'var(--accent-soft)', padding: '10px 16px', borderRadius: 10 }}>{coverEmoji}</div>
            <div style={{ flex: 1 }}>
              <h2 style={{ margin: '0 0 4px' }}>{title || '(no title)'}</h2>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>by {author}</div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>
                <span className="tag">{level}</span>
                <span className="tag">{genre}</span>
                <span className="tag">{chapters} chapters</span>
                {isFree ? <span className="tag">Free</span> : <span className="tag" style={{ color: 'var(--accent)', fontWeight: 'bold' }}>${parseFloat(price).toFixed(2)}</span>}
                {lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable up to {lendDays} days</span>}
              </div>
              <p style={{ fontSize: 13, margin: 0 }}>{desc}</p>
            </div>
          </div>
          {fileUrl && (
            <div className="card">
              <h3 style={{ marginTop: 0 }}>PDF preview</h3>
              <PdfViewer src={fileUrl} />
            </div>
          )}
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
        {step > 0 && <button className="btn ghost" onClick={() => setStep(s => s - 1)} style={{ flex: 1 }}>← Back</button>}
        {step < STEPS.length - 1 ? (
          <button className="btn" onClick={() => setStep(s => s + 1)} disabled={!canAdvance[step]} style={{ flex: 2 }}>
            Next: {STEPS[step + 1]} →
          </button>
        ) : (
          <button className="btn" onClick={handlePublish} style={{ flex: 2 }}>
            🚀 Publish to store
          </button>
        )}
      </div>
    </div>
  )
}
