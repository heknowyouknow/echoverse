import { STORE_BOOKS, MOCK_FRIENDS, LEND_DURATIONS } from '../data/mockData.js'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import PdfViewer from '../components/PdfViewer.jsx'
import LendModal from '../components/LendModal.jsx'
import Countdown, { useCountdown, formatRemaining, urgencyColor } from '../components/Countdown.jsx'

export default function MyBooks() {
  const { purchases, lentBooks, borrowedBooks, revokeLend, startReadingSession } = useApp()
  const [openBook,    setOpenBook]    = useState(null)
  const [lendBook,    setLendBook]    = useState(null)   // book being lent
  const [sessionBook, setSessionBook] = useState(null)   // book to start session from
  const [tab, setTab] = useState('owned')   // owned | lent | borrowed

  const ownedBooks = STORE_BOOKS.filter(b => purchases[b.id])
  const activeLends = lentBooks.filter(l => !l.expired)
  const expiredLends = lentBooks.filter(l => l.expired)

  return (
    <div>
      <h1>My Books</h1>

      {/* Tab switcher */}
      <div className="pill-row" style={{ marginBottom: 20 }}>
        <span className={`pill ${tab === 'owned' ? 'active' : ''}`} onClick={() => setTab('owned')}>
          📚 Owned ({ownedBooks.length})
        </span>
        <span className={`pill ${tab === 'lent' ? 'active' : ''}`} onClick={() => setTab('lent')}>
          🤝 Lent out ({activeLends.length})
        </span>
        <span className={`pill ${tab === 'borrowed' ? 'active' : ''}`} onClick={() => setTab('borrowed')}>
          📩 Borrowed ({borrowedBooks.length})
        </span>
      </div>

      {/* ── OWNED BOOKS ── */}
      {tab === 'owned' && (
        <>
          {ownedBooks.length === 0 && (
            <div className="card" style={{ textAlign: 'center', padding: 32 }}>
              <div style={{ fontSize: 48 }}>📭</div>
              <h3>No books yet</h3>
              <p style={{ color: 'var(--muted)' }}>Visit the store to buy your first book.</p>
              <Link to="/store"><button className="btn">Browse Store</button></Link>
            </div>
          )}
          <div className="grid">
            {ownedBooks.map(book => {
              const purchase = purchases[book.id]
              const myActiveLends = activeLends.filter(l => l.bookId === book.id)
              return (
                <div className="card" key={book.id} style={{ display: 'flex', flexDirection: 'column' }}>
                  <div style={{ display: 'flex', gap: 12, marginBottom: 10 }}>
                    <div style={{ fontSize: 44, background: 'var(--accent-soft)', borderRadius: 8, padding: '8px 12px' }}>
                      {book.coverEmoji}
                    </div>
                    <div style={{ flex: 1 }}>
                      <h3 style={{ margin: '0 0 2px' }}>{book.title}</h3>
                      <div style={{ fontSize: 12, color: 'var(--muted)' }}>{book.authorAvatar} {book.author}</div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>
                        Purchased {new Date(purchase.purchasedAt).toLocaleDateString()} · ${purchase.price.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
                    <span className="tag">{book.level}</span>
                    <span className="tag">{book.genre}</span>
                    <span className="tag">{book.format}</span>
                    {book.lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable</span>}
                  </div>

                  {/* Active lends for this book */}
                  {myActiveLends.length > 0 && (
                    <div style={{ background: '#f0faf3', borderRadius: 8, padding: '8px 10px', marginBottom: 10, fontSize: 12 }}>
                      <div style={{ fontWeight: 'bold', marginBottom: 4 }}>Currently lent to:</div>
                      {myActiveLends.map(l => (
                        <div key={l.lendId} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span>{l.toFriendAvatar} {l.toFriendName}</span>
                          <Countdown expiresAt={l.expiresAt} prefix="Expires" style={{ fontSize: 11 }} />
                          <button
                            className="btn ghost"
                            style={{ fontSize: 11, padding: '2px 8px', marginLeft: 'auto', color: '#8c2c2c', borderColor: '#8c2c2c' }}
                            onClick={() => revokeLend(l.lendId)}
                          >
                            Revoke
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Action buttons */}
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 'auto' }}>
                    <button className="btn" onClick={() => setOpenBook(book)}>
                      📖 Read
                    </button>
                    {book.lendable && (
                      <button className="btn secondary" onClick={() => setLendBook(book)}>
                        🤝 Lend
                      </button>
                    )}
                    <button className="btn ghost" onClick={() => setSessionBook(book)}>
                      🎭 Read together
                    </button>
                    <Link to={`/books/${book.id}`} style={{ marginLeft: 'auto' }}>
                      <button className="btn ghost" style={{ fontSize: 12 }}>Reviews</button>
                    </Link>
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}

      {/* ── LENT OUT ── */}
      {tab === 'lent' && (
        <>
          {activeLends.length === 0 && expiredLends.length === 0 && (
            <div className="card" style={{ textAlign: 'center', padding: 24 }}>
              <p style={{ color: 'var(--muted)' }}>You haven't lent any books yet. Open a book in "Owned" and tap Lend.</p>
            </div>
          )}

          {activeLends.length > 0 && (
            <>
              <h2 style={{ marginTop: 0 }}>Active lends</h2>
              {activeLends.map(l => (
                <LendCard key={l.lendId} lend={l} onRevoke={() => revokeLend(l.lendId)} />
              ))}
            </>
          )}

          {expiredLends.length > 0 && (
            <>
              <h2>Expired lends</h2>
              {expiredLends.map(l => (
                <div className="card" key={l.lendId} style={{ opacity: 0.6, display: 'flex', gap: 12, alignItems: 'center' }}>
                  <span style={{ fontSize: 30 }}>{l.bookEmoji}</span>
                  <div>
                    <div style={{ fontWeight: 'bold' }}>{l.bookTitle}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                      Lent to {l.toFriendAvatar} {l.toFriendName} · ⛔ Expired — access removed
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </>
      )}

      {/* ── BORROWED ── */}
      {tab === 'borrowed' && (
        <>
          {borrowedBooks.length === 0 && (
            <div className="card" style={{ textAlign: 'center', padding: 24 }}>
              <p style={{ color: 'var(--muted)' }}>No books have been lent to you right now.</p>
            </div>
          )}
          {borrowedBooks.map(b => (
            <BorrowedCard key={b.lendId} borrow={b} onOpen={() => setOpenBook({ ...b, title: b.bookTitle, coverEmoji: b.bookEmoji })} />
          ))}
        </>
      )}

      {/* PDF Reader overlay */}
      {openBook && (
        <div style={overlayStyle}>
          <div style={readerStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 style={{ margin: 0 }}>{openBook.coverEmoji} {openBook.title}</h3>
              <button className="btn ghost" onClick={() => setOpenBook(null)}>✕ Close</button>
            </div>
            <PdfViewer src={openBook.fileUrl || 'about:blank'} />
          </div>
        </div>
      )}

      {/* Lend modal */}
      {lendBook && <LendModal book={lendBook} onClose={() => setLendBook(null)} />}

      {/* Reading session starter */}
      {sessionBook && <SessionStarter book={sessionBook} onClose={() => setSessionBook(null)} />}
    </div>
  )
}

/* ── Sub-components ───────────────────────────────────────────────────── */

function LendCard({ lend, onRevoke }) {
  const remaining = useCountdown(lend.expiresAt)
  const color = urgencyColor(remaining)

  return (
    <div className="card" style={{ display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10 }}>
      <span style={{ fontSize: 36 }}>{lend.bookEmoji}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 'bold' }}>{lend.bookTitle}</div>
        <div style={{ fontSize: 13, color: 'var(--muted)', margin: '2px 0' }}>
          Lent to {lend.toFriendAvatar} <strong>{lend.toFriendName}</strong>
        </div>
        <div style={{ fontSize: 13 }}>
          <span style={{ color, fontWeight: 'bold' }}>⏱ {formatRemaining(remaining)} remaining</span>
        </div>
        {/* Mini progress bar */}
        <div style={{ marginTop: 6, background: 'var(--accent-soft)', borderRadius: 999, height: 4, overflow: 'hidden', maxWidth: 200 }}>
          <div style={{
            height: '100%', borderRadius: 999, background: color,
            width: `${100 - Math.round((remaining / (lend.expiresAt - lend.lentAt)) * 100)}%`,
            transition: 'width 1s'
          }} />
        </div>
        <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3 }}>
          Expires {new Date(lend.expiresAt).toLocaleString()}
        </div>
      </div>
      <button
        className="btn"
        style={{ background: '#8c2c2c', fontSize: 12 }}
        onClick={onRevoke}
      >
        Revoke access
      </button>
    </div>
  )
}

function BorrowedCard({ borrow, onOpen }) {
  const remaining = useCountdown(borrow.expiresAt)
  const expired = remaining <= 0

  return (
    <div className="card" style={{ display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10, opacity: expired ? 0.5 : 1 }}>
      <span style={{ fontSize: 36 }}>{borrow.bookEmoji}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 'bold' }}>{borrow.bookTitle}</div>
        <div style={{ fontSize: 13, color: 'var(--muted)' }}>Lent to you by <strong>{borrow.fromName}</strong></div>
        {expired
          ? <div style={{ color: '#8c2c2c', fontWeight: 'bold', fontSize: 13 }}>⛔ Time expired — access removed</div>
          : <Countdown expiresAt={borrow.expiresAt} prefix="Access ends in" />
        }
        {!expired && (
          <div style={{ marginTop: 6, background: 'var(--accent-soft)', borderRadius: 999, height: 4, overflow: 'hidden', maxWidth: 200 }}>
            <div style={{
              height: '100%', borderRadius: 999, background: urgencyColor(remaining),
              width: `${Math.round((remaining / (borrow.expiresAt - borrow.lentAt)) * 100)}%`,
              transition: 'width 1s'
            }} />
          </div>
        )}
      </div>
      {!expired && (
        <button className="btn" onClick={onOpen}>📖 Read now</button>
      )}
    </div>
  )
}

function SessionStarter({ book, onClose }) {
  const { startReadingSession } = useApp()
  const [selected, setSelected] = useState([])
  const [started,  setStarted]  = useState(false)
  

  function toggle(f) {
    setSelected(s => s.find(x => x.id === f.id) ? s.filter(x => x.id !== f.id) : [...s, f])
  }

  function start() {
    startReadingSession(book, selected)
    setStarted(true)
  }

  return (
    <div style={overlayStyle}>
      <div style={{ ...readerStyle, maxWidth: 440, height: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>🎭 Read "{book.title}" together</h3>
          <button className="btn ghost" onClick={onClose}>✕</button>
        </div>

        {!started ? (
          <>
            <p style={{ color: 'var(--muted)', fontSize: 13 }}>
              Invite friends to a shared reading session. They'll see the same PDF and can join your voice room. Only friends you've lent the book to (or who own it) can join.
            </p>
            <label>Invite friends</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {MOCK_FRIENDS.map(f => {
                const sel = selected.find(x => x.id === f.id)
                return (
                  <div key={f.id} onClick={() => toggle(f)} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px',
                    borderRadius: 8, cursor: 'pointer', border: `2px solid ${sel ? 'var(--accent)' : 'var(--accent-soft)'}`,
                    background: sel ? '#fff8f4' : 'white'
                  }}>
                    <span style={{ fontSize: 24 }}>{f.avatar}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 'bold', fontSize: 14 }}>{f.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--muted)' }}>{f.email}</div>
                    </div>
                    {sel && <span style={{ color: 'var(--accent)' }}>✓</span>}
                  </div>
                )
              })}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn ghost" onClick={onClose} style={{ flex: 1 }}>Cancel</button>
              <button className="btn" onClick={start} style={{ flex: 2 }}>
                Start session {selected.length > 0 ? `(+ ${selected.length} invited)` : '(solo)'}
              </button>
            </div>
          </>
        ) : (
          <div style={{ textAlign: 'center', padding: '10px 0 20px' }}>
            <div style={{ fontSize: 52 }}>🎭</div>
            <h3>Session started!</h3>
            {selected.length > 0 && (
              <p style={{ color: 'var(--muted)' }}>
                Invitations sent to {selected.map(f => f.name).join(', ')}. They'll get a notification to join.
              </p>
            )}
            <p style={{ fontSize: 12, color: 'var(--muted)' }}>
              Open the book to begin. A voice call bar will appear when friends join.
            </p>
            <button className="btn" onClick={onClose}>Open book →</button>
          </div>
        )}
      </div>
    </div>
  )
}

const overlayStyle = { position: 'fixed', inset: 0, background: 'rgba(43,36,24,0.78)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 150 }
const readerStyle = { background: 'var(--paper)', borderRadius: 14, width: '92%', maxWidth: 900, height: '88vh', padding: 20, display: 'flex', flexDirection: 'column', boxShadow: '0 12px 40px rgba(0,0,0,0.3)', overflowY: 'auto' }
