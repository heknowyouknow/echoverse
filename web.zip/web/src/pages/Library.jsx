import { useState } from 'react'
import { Link } from 'react-router-dom'
import { WRITER_BOOKS, WRITERS, LEVELS, SAMPLE_REVIEWS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'
import PdfViewer from '../components/PdfViewer.jsx'

export default function Library() {
  const { subscribedBooks, toggleSubscribe, reviews } = useApp()
  const [openBook, setOpenBook] = useState(null)
  const [levelFilter, setLevelFilter] = useState('All')
  const [search, setSearch] = useState('')

  const filtered = WRITER_BOOKS.filter(b => {
    if (levelFilter !== 'All' && b.level !== levelFilter) return false
    if (search && !b.title.toLowerCase().includes(search.toLowerCase()) && !b.writer.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  return (
    <div>
      <h1>Writer Library</h1>
      <p style={{ color: 'var(--muted)' }}>Books from independent writers — read or listen in-app. Subscribe to unlock full access.</p>

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 16 }}>
        <input placeholder="Search books or authors…" value={search} onChange={e => setSearch(e.target.value)} style={{ flex: 1, minWidth: 200, margin: 0 }} />
      </div>
      <div className="pill-row" style={{ marginBottom: 16 }}>
        {['All', ...LEVELS].map(l => (
          <span key={l} className={`pill ${levelFilter === l ? 'active' : ''}`} onClick={() => setLevelFilter(l)}>{l}</span>
        ))}
      </div>

      <div className="grid">
        {filtered.map(b => {
          const subbed = subscribedBooks.includes(b.id)
          const writer = WRITERS.find(w => w.bookIds.includes(b.id))
          const allReviews = [...(SAMPLE_REVIEWS[b.id] || []), ...(reviews[b.id] || [])]
          const avgRating = allReviews.length
            ? (allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length).toFixed(1)
            : null

          return (
            <div className="card" key={b.id}>
              <div style={{ display: 'flex', gap: 10, marginBottom: 8 }}>
                <span style={{ fontSize: 36 }}>{b.coverEmoji}</span>
                <div>
                  <span className="tag">{b.level}</span>
                  <span className="tag">{b.genre}</span>
                  <span className="tag">{b.format}</span>
                </div>
              </div>
              <h3 style={{ margin: '0 0 2px' }}>{b.title}</h3>
              {writer && (
                <Link to={`/writers/${writer.id}`} style={{ fontSize: 12, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>
                  {writer.avatar} {writer.name}
                </Link>
              )}
              <p style={{ fontSize: 13 }}>{b.description}</p>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
                {b.chapters} chapters · {b.price}
                {avgRating && <span style={{ marginLeft: 8 }}>⭐ {avgRating} ({allReviews.length})</span>}
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button className={subbed ? 'btn secondary' : 'btn'} onClick={() => toggleSubscribe(b.id)}>
                  {subbed ? '✓ Subscribed' : 'Subscribe'}
                </button>
                {subbed && <button className="btn ghost" onClick={() => setOpenBook(b)}>Open {b.format.includes('Audio') ? '🔊' : '📄'}</button>}
                <Link to={`/books/${b.id}`}><button className="btn ghost">Reviews</button></Link>
              </div>
            </div>
          )
        })}
        {filtered.length === 0 && <div className="card" style={{ color: 'var(--muted)' }}>No books matched. Try clearing the filter.</div>}
      </div>

      {/* Writers section */}
      <h2 style={{ marginTop: 24 }}>Meet the writers</h2>
      <div className="grid">
        {WRITERS.map(w => (
          <div className="card" key={w.id} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 36 }}>{w.avatar}</span>
            <div style={{ flex: 1 }}>
              <strong>{w.name}</strong>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 4 }}>{w.location}</div>
              <p style={{ fontSize: 13, margin: '0 0 8px' }}>{w.bio.slice(0, 80)}…</p>
              <Link to={`/writers/${w.id}`}><button className="btn secondary" style={{ fontSize: 12, padding: '4px 10px' }}>View profile</button></Link>
            </div>
          </div>
        ))}
      </div>

      {/* Full-screen reader overlay */}
      {openBook && (
        <div style={overlay}>
          <div style={readerPanel}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 style={{ margin: 0 }}>{openBook.coverEmoji} {openBook.title}</h3>
              <button className="btn ghost" onClick={() => setOpenBook(null)}>✕ Close</button>
            </div>
            {openBook.format.includes('Audio')
              ? <AudioPlayer book={openBook} />
              : <PdfViewer src={openBook.fileUrl || 'about:blank'} />
            }
          </div>
        </div>
      )}
    </div>
  )
}

function AudioPlayer({ book }) {
  const [playing, setPlaying] = useState(false)
  function toggle() {
    if (!playing) {
      const u = new SpeechSynthesisUtterance(`Audio read-along for ${book.title} by ${book.writer}. Connect a real audio file URL in mockData to replace this placeholder.`)
      u.rate = 0.9; u.onend = () => setPlaying(false)
      window.speechSynthesis.speak(u)
    } else { window.speechSynthesis.cancel() }
    setPlaying(p => !p)
  }
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
      <div style={{ fontSize: 64 }}>{book.coverEmoji}</div>
      <h2>{book.title}</h2>
      <p style={{ color: 'var(--muted)' }}>by {book.writer}</p>
      <button className="btn" onClick={toggle} style={{ fontSize: 20, padding: '12px 32px' }}>
        {playing ? '⏸ Pause' : '▶ Play audio'}
      </button>
      <p style={{ fontSize: 12, color: 'var(--muted)' }}>Demo TTS · Add real audio URL to mockData.js</p>
    </div>
  )
}

const overlay     = { position: 'fixed', inset: 0, background: 'rgba(43,36,24,0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 120 }
const readerPanel = { background: 'white', borderRadius: 14, width: '92%', maxWidth: 900, height: '90vh', padding: 20, display: 'flex', flexDirection: 'column', boxShadow: '0 12px 40px rgba(0,0,0,0.3)' }
