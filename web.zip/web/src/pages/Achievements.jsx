import { useApp } from '../context/AppContext.jsx'
import { ACHIEVEMENTS } from '../data/mockData.js'

const LEVEL_NAMES = ['Seedling', 'Reader', 'Storyteller', 'Narrator', 'Voice', 'Bard', 'Griot']

export default function Achievements() {
  const { earned, xp, totalXpLevel, history, myRooms } = useApp()
  const xpToNext = totalXpLevel * 50
  const xpThisLevel = xp - (totalXpLevel - 1) * 50
  const pct = Math.min(100, Math.round((xpThisLevel / 50) * 100))
  const levelName = LEVEL_NAMES[Math.min(totalXpLevel - 1, LEVEL_NAMES.length - 1)]

  return (
    <div>
      <h1>Achievements</h1>

      {/* XP & Level bar */}
      <div className="card" style={{ display: 'flex', gap: 20, alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ fontSize: 52 }}>🏆</div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
            <strong style={{ fontSize: 18 }}>Level {totalXpLevel} — {levelName}</strong>
            <span style={{ color: 'var(--muted)', fontSize: 13 }}>{xp} XP total</span>
          </div>
          <div style={barTrack}>
            <div style={{ ...barFill, width: `${pct}%` }} />
          </div>
          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
            {xpThisLevel} / 50 XP to Level {totalXpLevel + 1}
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 22, fontWeight: 'bold', color: 'var(--accent)' }}>{earned.size}</div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>badges earned</div>
        </div>
      </div>

      {/* Stats strip */}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', margin: '16px 0' }}>
        {[
          { label: 'Stories completed', value: history.length },
          { label: 'Rooms joined', value: myRooms.length },
          { label: 'XP earned', value: xp },
          { label: 'Badges', value: `${earned.size} / ${ACHIEVEMENTS.length}` },
        ].map(s => (
          <div key={s.label} style={statBox}>
            <div style={{ fontSize: 22, fontWeight: 'bold', color: 'var(--accent)' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Badge grid */}
      <h2>Badges</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(170px, 1fr))', gap: 12 }}>
        {ACHIEVEMENTS.map(a => {
          const isEarned = earned.has(a.id)
          return (
            <div key={a.id} style={{ ...badgeCard, opacity: isEarned ? 1 : 0.4, border: isEarned ? '2px solid var(--accent)' : '1px solid var(--accent-soft)' }}>
              <div style={{ fontSize: 32 }}>{a.emoji}</div>
              <div style={{ fontWeight: 'bold', fontSize: 13, margin: '4px 0 2px' }}>{a.name}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>{a.desc}</div>
              <div style={{ fontSize: 11, color: 'var(--accent)', marginTop: 4 }}>+{a.xp} XP</div>
              {isEarned && <div style={{ fontSize: 11, color: 'var(--good)', marginTop: 2 }}>✓ Earned</div>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

const barTrack = { background: 'var(--accent-soft)', borderRadius: 999, height: 12, overflow: 'hidden' }
const barFill  = { background: 'var(--accent)', height: '100%', borderRadius: 999, transition: 'width 0.4s ease' }
const statBox  = { background: 'white', border: '1px solid var(--accent-soft)', borderRadius: 10, padding: '14px 18px', textAlign: 'center', flex: '1 1 110px' }
const badgeCard = { background: 'white', borderRadius: 10, padding: '14px 12px', textAlign: 'center' }
