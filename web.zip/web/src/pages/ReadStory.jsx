import { useState, useEffect, useRef } from 'react'
import { useParams, Link } from 'react-router-dom'
import { STORY_LIBRARY, CHARACTER_COLORS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'
import WaitingRoom from '../components/WaitingRoom.jsx'

export default function ReadStory() {
  const { id } = useParams()
  const { user, updateProgress, progress, bookmarks, setBookmark, ttsVoiceIndex, earnAchievement } = useApp()
  const story = STORY_LIBRARY.find(s => s.id === id)

  const [myCharacter, setMyCharacter] = useState(null)
  const [currentLine, setCurrentLine] = useState(bookmarks[id] ?? 0)
  const [speaking, setSpeaking] = useState(false)
  const [fontSize, setFontSize] = useState(18)
  const [showWaiting, setShowWaiting] = useState(false)
  const [ttsCount, setTtsCount] = useState(0)
  const lineRefs = useRef({})
  const utterRef = useRef(null)

  // Map each unique character to a colour
  const chars = story ? [...new Set(story.script.map(l => l.character))] : []
  const colorMap = Object.fromEntries(chars.map((c, i) => [c, CHARACTER_COLORS[i % CHARACTER_COLORS.length]]))

  // Track progress
  useEffect(() => {
    if (!story || !myCharacter) return
    updateProgress(id, currentLine + 1, story.script.length, myCharacter, story.title)
  }, [currentLine, myCharacter])

  // Scroll active line into view
  useEffect(() => {
    lineRefs.current[currentLine]?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
  }, [currentLine])

  // TTS achievement
  useEffect(() => {
    if (ttsCount >= 10) earnAchievement('listener')
  }, [ttsCount])

  if (!story) return <div className="card">Story not found. <Link to="/explore">Browse Explore</Link>.</div>

  const storyProgress = progress[id]
  const pct = storyProgress ? Math.round((storyProgress.linesRead / story.script.length) * 100) : 0

  function speakLine(text) {
    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(text)
    const voices = window.speechSynthesis.getVoices()
    if (voices[ttsVoiceIndex]) u.voice = voices[ttsVoiceIndex]
    u.rate = 0.88
    u.onstart = () => setSpeaking(true)
    u.onend   = () => { setSpeaking(false); setTtsCount(c => c + 1) }
    utterRef.current = u
    window.speechSynthesis.speak(u)
  }

  function stopSpeech() { window.speechSynthesis?.cancel(); setSpeaking(false) }

  function readAll() {
    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const fullText = story.script.map(l => `${l.character}. ${l.line}`).join(' ')
    const u = new SpeechSynthesisUtterance(fullText)
    const voices = window.speechSynthesis.getVoices()
    if (voices[ttsVoiceIndex]) u.voice = voices[ttsVoiceIndex]
    u.rate = 0.85
    u.onstart = () => setSpeaking(true)
    u.onend = () => { setSpeaking(false); setTtsCount(c => c + 5) }
    utterRef.current = u
    window.speechSynthesis.speak(u)
  }

  function advanceLine() {
    if (currentLine < story.script.length - 1) setCurrentLine(l => l + 1)
  }
  function prevLine() { if (currentLine > 0) setCurrentLine(l => l - 1) }

  return (
    <div>
      {showWaiting && (
        <WaitingRoom
          storyId={id}
          characterCount={story.characterOptions[0]}
          onCancel={() => setShowWaiting(false)}
        />
      )}

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
        <span style={{ fontSize: 40 }}>{story.coverEmoji}</span>
        <div style={{ flex: 1 }}>
          <h1 style={{ margin: 0 }}>{story.title}</h1>
          <span className="tag">{story.level}</span>
          <span className="tag">{story.genre}</span>
          {story.author && <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 6 }}>by {story.author}</span>}
        </div>
        <button className="btn secondary" onClick={() => setShowWaiting(true)}>
          🎭 Read with others
        </button>
      </div>

      {/* Progress bar */}
      {myCharacter && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--muted)', marginBottom: 4 }}>
            <span>Progress</span>
            <span>{pct}% · line {currentLine + 1} of {story.script.length}</span>
          </div>
          <div style={{ background: 'var(--accent-soft)', borderRadius: 999, height: 6, overflow: 'hidden' }}>
            <div style={{ background: 'var(--accent)', width: `${pct}%`, height: '100%', borderRadius: 999, transition: 'width 0.3s' }} />
          </div>
          {storyProgress?.completed && (
            <div style={{ fontSize: 12, color: 'var(--good)', marginTop: 4 }}>✓ Completed! Great reading.</div>
          )}
        </div>
      )}

      {/* Character picker */}
      {!myCharacter ? (
        <div className="card">
          <h3>Choose your character</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13 }}>Your lines will be highlighted. Other parts dim so you can focus on your cues.</p>
          <div className="pill-row">
            {chars.map(c => (
              <span
                key={c}
                onClick={() => { setMyCharacter(c); if (c === 'Narrator') earnAchievement('narrator') }}
                style={{ ...pillChar, borderColor: colorMap[c], color: colorMap[c] }}
              >
                {c}
              </span>
            ))}
            <span className="pill" onClick={() => setMyCharacter('__all__')}>Read all parts</span>
          </div>
          {bookmarks[id] != null && (
            <p style={{ fontSize: 13, marginTop: 8 }}>
              📌 You have a bookmark at line {bookmarks[id] + 1}.{' '}
              <span style={{ color: 'var(--accent)', cursor: 'pointer' }} onClick={() => setCurrentLine(bookmarks[id])}>
                Resume from there
              </span>
            </p>
          )}
        </div>
      ) : (
        /* Controls toolbar */
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10, padding: '8px 0', borderBottom: '1px solid var(--accent-soft)' }}>
          <span style={{ fontSize: 13 }}>
            Reading as:{' '}
            <strong style={{ color: myCharacter === '__all__' ? 'var(--ink)' : colorMap[myCharacter] }}>
              {myCharacter === '__all__' ? 'all parts' : myCharacter}
            </strong>
          </span>
          <div style={{ flex: 1 }} />
          <button className="btn ghost" onClick={prevLine} disabled={currentLine === 0}>←</button>
          <button className="btn ghost" onClick={advanceLine} disabled={currentLine === story.script.length - 1}>→</button>
          <button className="btn ghost" onClick={() => setFontSize(f => Math.max(14, f - 2))}>A−</button>
          <button className="btn ghost" onClick={() => setFontSize(f => Math.min(28, f + 2))}>A+</button>
          <button
            className="btn ghost"
            title="Bookmark this line"
            onClick={() => { setBookmark(id, currentLine); }}
          >
            {bookmarks[id] === currentLine ? '🔖' : '📌'}
          </button>
          {!speaking
            ? <button className="btn secondary" onClick={readAll}>🔊 Read aloud</button>
            : <button className="btn" onClick={stopSpeech}>⏹ Stop</button>
          }
          <button className="btn ghost" onClick={() => setMyCharacter(null)}>Switch</button>
        </div>
      )}

      {/* Script */}
      {myCharacter && (
        <div className="reading-screen" style={{ fontSize }}>
          {story.script.map((line, i) => {
            const isMine = myCharacter === '__all__' || line.character === myCharacter
            const isActive = i === currentLine
            const color = colorMap[line.character]
            return (
              <div
                key={i}
                ref={el => (lineRefs.current[i] = el)}
                onClick={() => { setCurrentLine(i); speakLine(`${line.character}: ${line.line}`) }}
                style={{
                  padding: '6px 10px',
                  borderRadius: 6,
                  marginBottom: 2,
                  background: isActive ? '#fff4ec' : 'transparent',
                  borderLeft: `3px solid ${isMine ? color : 'transparent'}`,
                  opacity: (!isMine && myCharacter !== '__all__') ? 0.5 : 1,
                  cursor: 'pointer',
                  transition: 'background 0.15s',
                  outline: isActive ? `2px solid ${color}22` : 'none'
                }}
              >
                <b style={{ color }}>{line.character}:</b>{' '}{line.line}
                {bookmarks[id] === i && <span style={{ marginLeft: 8, fontSize: 12 }}>🔖</span>}
              </div>
            )
          })}
        </div>
      )}

      {/* Bottom CTAs */}
      <div className="card" style={{ marginTop: 16, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <button className="btn secondary" onClick={() => setShowWaiting(true)}>🎭 Request reading partners</button>
        <Link to="/rooms"><button className="btn ghost">Browse live rooms</button></Link>
        <Link to={`/books/${id}`}><button className="btn ghost">Reviews</button></Link>
      </div>
    </div>
  )
}

const pillChar = {
  display: 'inline-block',
  border: '2px solid',
  borderRadius: 999,
  padding: '6px 14px',
  cursor: 'pointer',
  fontWeight: 'bold',
  fontSize: 13
}
