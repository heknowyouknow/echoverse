import { useState } from 'react'
import { useLocation, Link } from 'react-router-dom'
import { LEVELS, GENRES, STORY_LIBRARY, generateStory } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

export default function CreateStoryRequest() {
  const location = useLocation()
  const preselected = location.state?.storyId
  const { user, addNotification } = useApp()

  const [tab, setTab] = useState(preselected ? 'published' : 'ai')
  const [level, setLevel] = useState(user?.level || LEVELS[0])
  const [genre, setGenre] = useState(GENRES[0])
  const [characterCount, setCharacterCount] = useState(2)
  const [theme, setTheme] = useState('')
  const [chosenBook, setChosenBook] = useState(preselected ? STORY_LIBRARY.find(s => s.id === preselected) : null)
  const [generated, setGenerated] = useState(null)
  const [loading, setLoading] = useState(false)
  const [partnersRequested, setPartnersRequested] = useState(false)

  const publishedOptions = STORY_LIBRARY.filter(s => s.source !== 'AI-generated')

  async function handleGenerate() {
    setLoading(true)
    setGenerated(null)
    const story = await generateStory({ level, characterCount, theme, genre })
    setGenerated(story)
    setLoading(false)
    setPartnersRequested(false)
  }

  const readyStory = tab === 'ai' ? generated : chosenBook
  const charCount = readyStory ? (readyStory.characterOptions?.[0] || characterCount) : characterCount

  function requestPartners() {
    setPartnersRequested(true)
    for (let i = 1; i < charCount; i++) {
      addNotification({
        type: 'partner_request',
        from: user?.name || 'You',
        message: `sent a partner request for Character ${i + 1} in "${readyStory?.title}"`,
        roomId: null
      })
    }
  }

  return (
    <div>
      <h1>Request a character-based story</h1>
      <p style={{ color: 'var(--muted)' }}>Choose how many characters the piece needs, then request reading partners — one per character.</p>

      <div className="pill-row" style={{ marginBottom: 16 }}>
        <span className={`pill ${tab === 'ai' ? 'active' : ''}`} onClick={() => { setTab('ai'); setChosenBook(null) }}>✨ AI-generated</span>
        <span className={`pill ${tab === 'published' ? 'active' : ''}`} onClick={() => { setTab('published'); setGenerated(null) }}>📖 Published book</span>
      </div>

      <div className="card">
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 180 }}>
            <label>Reading level</label>
            <select value={level} onChange={e => setLevel(e.target.value)}>
              {LEVELS.map(l => <option key={l}>{l}</option>)}
            </select>
          </div>
          <div style={{ flex: 1, minWidth: 180 }}>
            <label>Genre</label>
            <select value={genre} onChange={e => setGenre(e.target.value)}>
              {GENRES.map(g => <option key={g}>{g}</option>)}
            </select>
          </div>
          <div style={{ flex: 1, minWidth: 180 }}>
            <label>Number of characters</label>
            <select value={characterCount} onChange={e => setCharacterCount(Number(e.target.value))}>
              {[2, 3, 4, 5, 6].map(n => <option key={n} value={n}>{n} characters</option>)}
            </select>
          </div>
        </div>

        {tab === 'ai' && (
          <>
            <label>Theme (optional)</label>
            <input value={theme} onChange={e => setTheme(e.target.value)} placeholder="e.g. a folktale about two rivers, a market morning…" />
            <button className="btn" onClick={handleGenerate} disabled={loading}>
              {loading ? '✨ Generating…' : '✨ Generate story'}
            </button>
          </>
        )}

        {tab === 'published' && (
          <div style={{ marginTop: 10 }}>
            <label>Choose a published work</label>
            {publishedOptions.map(s => (
              <div className="char-slot" key={s.id}>
                <div>
                  <strong>{s.title}</strong>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>{s.author} · {s.level} · {s.genre}</div>
                </div>
                <button
                  className={chosenBook?.id === s.id ? 'btn' : 'btn secondary'}
                  onClick={() => setChosenBook(s)}
                >
                  {chosenBook?.id === s.id ? 'Selected ✓' : 'Select'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {readyStory && (
        <div className="card">
          <div style={{ fontSize: 36 }}>{readyStory.coverEmoji || '📖'}</div>
          <h3>{readyStory.title}</h3>
          <p style={{ fontSize: 13 }}>{readyStory.description}</p>
          <div className="pill-row" style={{ marginBottom: 12 }}>
            {Array.from({ length: charCount }, (_, i) => (
              <span className="pill active" key={i}>
                {readyStory.script?.[i]?.character || `Character ${i + 1}`}
              </span>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <Link to={`/read/${readyStory.id}`}><button className="btn secondary">Preview</button></Link>
            <button className="btn" disabled={partnersRequested} onClick={requestPartners}>
              {partnersRequested
                ? `✓ ${charCount - 1} partner request(s) sent`
                : `Request ${charCount - 1} reading partner(s)`
              }
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
