import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import { WRITER_BOOKS, STORY_LIBRARY, ACHIEVEMENTS, WRITERS } from '../data/mockData.js'

const LEVEL_NAMES = ['Seedling', 'Reader', 'Storyteller', 'Narrator', 'Voice', 'Bard', 'Griot']

export default function Dashboard() {
  const { user, subscribedBooks, myRooms, history, earned, xp, totalXpLevel, followedWriters, notifications } = useApp()
  if (!user) return <div className="card">Please complete onboarding first.</div>

  const subBooks    = WRITER_BOOKS.filter(b => subscribedBooks.includes(b.id))
  const levelName   = LEVEL_NAMES[Math.min(totalXpLevel - 1, LEVEL_NAMES.length - 1)]
  const xpThisLevel = xp - (totalXpLevel - 1) * 50
  const pct         = Math.min(100, Math.round((xpThisLevel / 50) * 100))
  const recentBadges = [...earned].map(id => ACHIEVEMENTS.find(a => a.id === id)).filter(Boolean).slice(-3)
  const recommended  = STORY_LIBRARY.filter(s => s.level === user.level).slice(0, 2)
  const followedList = WRITERS.filter(w => followedWriters.includes(w.id))

  return (
    <div>
      {/* Profile hero */}
      <div className="card" style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap', marginBottom: 20 }}>
        <div style={{ fontSize: 56 }}>{user.avatar}</div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
            <div>
              <h2 style={{ margin: 0 }}>{user.name}</h2>
              <span className="tag">{user.level}</span>
              <span className="tag">{user.role}</span>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontWeight: 'bold', color: 'var(--accent)' }}>Level {totalXpLevel} — {levelName}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>{xp} XP</div>
            </div>
          </div>
          {/* XP bar */}
          <div style={{ marginTop: 10 }}>
            <div style={{ background: 'var(--accent-soft)', borderRadius: 999, height: 8, overflow: 'hidden' }}>
              <div style={{ background: 'var(--accent)', width: `${pct}%`, height: '100%', borderRadius: 999, transition: 'width 0.4s' }} />
            </div>
            <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3 }}>
              {xpThisLevel}/50 XP to Level {totalXpLevel + 1}
            </div>
          </div>
          {recentBadges.length > 0 && (
            <div style={{ marginTop: 8 }}>
              {recentBadges.map(b => (
                <span key={b.id} title={b.name} style={{ fontSize: 20, marginRight: 4 }}>{b.emoji}</span>
              ))}
              <Link to="/achievements" style={{ fontSize: 12, marginLeft: 4 }}>View all badges →</Link>
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/achievements"><button className="btn secondary">🏆 Achievements</button></Link>
          <Link to="/settings"><button className="btn ghost">⚙️ Settings</button></Link>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 20 }}>
        {[
          { label: 'Stories completed', value: history.length },
          { label: 'Rooms joined', value: myRooms.length },
          { label: 'Books subscribed', value: subBooks.length },
          { label: 'Badges earned', value: `${earned.size}/${ACHIEVEMENTS.length}` },
        ].map(s => (
          <div key={s.label} style={{ background: 'white', border: '1px solid var(--accent-soft)', borderRadius: 10, padding: '12px 16px', flex: '1 1 110px', textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 'bold', color: 'var(--accent)' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid">
        {/* Reading history */}
        <div className="card">
          <h3>📜 Reading history</h3>
          {history.length === 0 && <p style={{ color: 'var(--muted)', fontSize: 13 }}>No completed stories yet. <Link to="/explore">Start reading</Link>.</p>}
          {history.map((h, i) => (
            <div key={i} style={{ padding: '6px 0', borderBottom: '1px solid var(--accent-soft)', fontSize: 13 }}>
              <strong>{h.title}</strong>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>as {h.character} · {h.completedAt?.slice(0, 10)}</div>
            </div>
          ))}
        </div>

        {/* Subscribed books */}
        <div className="card">
          <h3>📚 My subscribed books</h3>
          {subBooks.length === 0
            ? <p style={{ color: 'var(--muted)', fontSize: 13 }}><Link to="/library">Browse the library</Link> to subscribe.</p>
            : subBooks.map(b => (
              <div key={b.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', borderBottom: '1px solid var(--accent-soft)' }}>
                <span style={{ fontSize: 22 }}>{b.coverEmoji}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 'bold', fontSize: 13 }}>{b.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>{b.writer}</div>
                </div>
                <Link to="/library"><button className="btn ghost" style={{ fontSize: 11, padding: '3px 8px' }}>Open</button></Link>
              </div>
            ))
          }
        </div>

        {/* My rooms */}
        <div className="card">
          <h3>🎭 My reading rooms</h3>
          {myRooms.length === 0
            ? <p style={{ color: 'var(--muted)', fontSize: 13 }}><Link to="/rooms">Join a room</Link> or <Link to="/create">start a request</Link>.</p>
            : myRooms.map(r => (
              <div key={r.id} style={{ padding: '6px 0', borderBottom: '1px solid var(--accent-soft)' }}>
                <div style={{ fontWeight: 'bold', fontSize: 13 }}>{r.title}</div>
                <Link to={`/rooms/${r.id}`}><button className="btn secondary" style={{ fontSize: 11, padding: '3px 10px', marginTop: 4 }}>Enter</button></Link>
              </div>
            ))
          }
        </div>

        {/* Followed writers */}
        <div className="card">
          <h3>✍️ Writers I follow</h3>
          {followedList.length === 0
            ? <p style={{ color: 'var(--muted)', fontSize: 13 }}>Follow a writer from their <Link to="/library">library profile</Link>.</p>
            : followedList.map(w => (
              <div key={w.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', borderBottom: '1px solid var(--accent-soft)' }}>
                <span style={{ fontSize: 22 }}>{w.avatar}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 'bold', fontSize: 13 }}>{w.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>{w.location}</div>
                </div>
                <Link to={`/writers/${w.id}`}><button className="btn ghost" style={{ fontSize: 11, padding: '3px 8px' }}>Profile</button></Link>
              </div>
            ))
          }
        </div>
      </div>

      {/* Recommended */}
      {recommended.length > 0 && (
        <>
          <h2>Recommended for {user.level}</h2>
          <div className="grid">
            {recommended.map(s => (
              <div className="card" key={s.id}>
                <span style={{ fontSize: 28 }}>{s.coverEmoji}</span>
                <span className="tag" style={{ marginLeft: 8 }}>{s.genre}</span>
                <h3 style={{ margin: '8px 0 4px' }}>{s.title}</h3>
                <p style={{ fontSize: 13 }}>{s.description}</p>
                <Link to={`/read/${s.id}`}><button className="btn secondary">Read now</button></Link>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
