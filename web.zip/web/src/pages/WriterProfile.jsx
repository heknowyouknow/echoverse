import { useParams, Link } from 'react-router-dom'
import { WRITERS, STORE_BOOKS, SAMPLE_REVIEWS, AUTHOR_STATS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

function StarRow({ rating }) {
  return <span style={{ color: '#f5a623' }}>{'★'.repeat(Math.round(rating))}{'☆'.repeat(5 - Math.round(rating))}</span>
}

export default function WriterProfile() {
  const { id } = useParams()
  const { followedWriters, toggleFollow, purchases, purchaseBook, reviews } = useApp()
  const writer = WRITERS.find(w => w.id === id)
  if (!writer) return <div className="card">Writer not found. <Link to="/library">Browse library</Link>.</div>

  const books    = STORE_BOOKS.filter(b => b.authorId === id)
  const stats    = AUTHOR_STATS[id]
  const isFollowing = followedWriters.includes(id)
  const allReviews = books.flatMap(b => [...(SAMPLE_REVIEWS[b.id] || []), ...(reviews[b.id] || [])])
  const avgRating = allReviews.length ? (allReviews.reduce((s,r) => s + r.rating, 0) / allReviews.length).toFixed(1) : null

  return (
    <div>
      {/* Profile hero */}
      <div className="card" style={{ display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap', marginBottom: 20 }}>
        <div style={{ fontSize: 72 }}>{writer.avatar}</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 4 }}>
            <h1 style={{ margin: 0 }}>{writer.name}</h1>
            <span style={{ background: '#e8f5e9', color: '#3f6b4a', fontSize: 12, padding: '3px 10px', borderRadius: 999, fontWeight: 'bold' }}>
              ✓ Verified Author
            </span>
          </div>
          <div style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 10 }}>
            📍 {writer.location} · Member since {writer.joined}
          </div>
          <p style={{ margin: '0 0 14px' }}>{writer.bio}</p>

          {/* Stats strip */}
          <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', marginBottom: 14 }}>
            <Stat label="followers"  value={writer.followers + (isFollowing ? 1 : 0)} />
            <Stat label="books"      value={books.length} />
            {stats && <Stat label="readers"   value={stats.readers} />}
            {stats && <Stat label="total sales" value={stats.totalSales} />}
            {avgRating && <Stat label="avg rating" value={`⭐ ${avgRating}`} />}
          </div>

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className={isFollowing ? 'btn secondary' : 'btn'} onClick={() => toggleFollow(id)}>
              {isFollowing ? '✓ Following' : '+ Follow'}
            </button>
            {id === 'w1' && (
              <Link to="/author-dashboard">
                <button className="btn ghost">📊 My dashboard</button>
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Books for sale */}
      <h2>Books by {writer.name}</h2>
      <div className="grid">
        {books.map(b => {
          const owned = !!purchases[b.id]
          const bookReviews = [...(SAMPLE_REVIEWS[b.id] || []), ...(reviews[b.id] || [])]
          const avg = bookReviews.length
            ? (bookReviews.reduce((s,r) => s + r.rating, 0) / bookReviews.length).toFixed(1) : null

          return (
            <div className="card" key={b.id} style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ fontSize: 44, background: 'var(--accent-soft)', borderRadius: 8, textAlign: 'center', padding: '12px 0', marginBottom: 10 }}>
                {b.coverEmoji}
              </div>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 8 }}>
                <span className="tag">{b.level}</span>
                <span className="tag">{b.genre}</span>
                <span className="tag">{b.format}</span>
                {b.lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable</span>}
              </div>
              <h3 style={{ margin: '0 0 4px' }}>{b.title}</h3>
              <p style={{ fontSize: 13, flex: 1 }}>{b.description}</p>
              {avg && (
                <div style={{ fontSize: 13, marginBottom: 8 }}>
                  <StarRow rating={avg} /> {avg} ({bookReviews.length} review{bookReviews.length !== 1 ? 's' : ''})
                </div>
              )}
              <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
                {b.pages} pages · {b.chapters} chapters · {b.sales} sold
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 20, fontWeight: 'bold', color: 'var(--accent)' }}>
                  ${b.price.toFixed(2)}
                </span>
                <div style={{ flex: 1 }} />
                <Link to={`/books/${b.id}`}><button className="btn ghost" style={{ fontSize: 12 }}>Preview</button></Link>
                {owned
                  ? <Link to="/mybooks"><button className="btn secondary">In My Books ✓</button></Link>
                  : <button className="btn" onClick={() => purchaseBook(b)}>Buy now</button>
                }
              </div>
            </div>
          )
        })}
      </div>

      {/* Recent reviews across all books */}
      {allReviews.length > 0 && (
        <>
          <h2>Reader reviews</h2>
          {allReviews.slice(0, 4).map(r => (
            <div className="card" key={r.id} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 20 }}>{r.avatar}</span>
                  <strong>{r.user}</strong>
                </div>
                <span style={{ color: '#f5a623' }}>{'★'.repeat(r.rating)}</span>
              </div>
              <p style={{ margin: 0, fontSize: 14 }}>{r.text}</p>
            </div>
          ))}
        </>
      )}
    </div>
  )
}

function Stat({ label, value }) {
  return (
    <span>
      <strong style={{ fontSize: 18 }}>{value}</strong>{' '}
      <span style={{ color: 'var(--muted)', fontSize: 13 }}>{label}</span>
    </span>
  )
}
