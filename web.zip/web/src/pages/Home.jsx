import { Link } from 'react-router-dom'
import { STORY_LIBRARY, READING_ROOMS } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

export default function Home() {
  const { user } = useApp()

  const openRooms = READING_ROOMS.filter(r => r.status === 'open').slice(0, 2)
  const featured = STORY_LIBRARY.slice(0, 3)

  return (
    <div>
      <div style={{ textAlign: 'center', padding: '32px 0 24px' }}>
        <div style={{ fontSize: 56 }}>📖</div>
        <h1 style={{ fontSize: 32, marginBottom: 8 }}>Read together, out loud.</h1>
        <p style={{ color: 'var(--muted)', maxWidth: 500, margin: '0 auto 20px' }}>
          Group poetry and story reading for every level — Primary to University.
          Join a live room, request partners, or subscribe to a writer's book.
        </p>
        <Link to="/explore"><button className="btn" style={{ fontSize: 16, padding: '10px 24px' }}>Browse all stories</button></Link>
        &nbsp;&nbsp;
        <Link to="/rooms"><button className="btn secondary" style={{ fontSize: 16, padding: '10px 24px' }}>Join a live room</button></Link>
      </div>

      <h2>Live rooms open now</h2>
      <div className="grid">
        {openRooms.map(r => (
          <div className="card" key={r.id}>
            <span className="tag">{r.level}</span>
            <h3>{r.title}</h3>
            <p style={{ fontSize: 13, color: 'var(--muted)' }}>{r.description}</p>
            <div className="char-slot">
              <span>Open parts: {r.charactersNeeded.filter(c => !r.charactersFilled[c]).join(', ')}</span>
            </div>
            <div style={{ marginTop: 10 }}>
              <Link to={`/rooms/${r.id}`}><button className="btn">Open room</button></Link>
            </div>
          </div>
        ))}
      </div>

      <h2>Featured stories</h2>
      <div className="grid">
        {featured.map(s => (
          <div className="card" key={s.id}>
            <span style={{ fontSize: 32 }}>{s.coverEmoji}</span>
            <span className="tag" style={{ marginLeft: 8 }}>{s.level}</span>
            <span className="tag">{s.genre}</span>
            <h3 style={{ margin: '8px 0 4px' }}>{s.title}</h3>
            <p style={{ fontSize: 13 }}>{s.description}</p>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
              {s.characterOptions.join(' or ')} characters
            </div>
            <Link to={`/read/${s.id}`}><button className="btn secondary">Read now</button></Link>
          </div>
        ))}
      </div>

      <div className="grid" style={{ marginTop: 8 }}>
        <div className="card">
          <h3>🖋️ Are you a writer?</h3>
          <p>Upload your book as a PDF or text and offer it to readers by subscription.</p>
          <Link to="/upload"><button className="btn">Upload a book</button></Link>
        </div>
        <div className="card">
          <h3>✍️ Request a story</h3>
          <p>Pick a theme, a character count, and we'll generate a story and find your reading partners.</p>
          <Link to="/create"><button className="btn">Request a story</button></Link>
        </div>
      </div>
    </div>
  )
}
