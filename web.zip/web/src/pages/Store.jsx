import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { STORE_BOOKS, LEVELS, GENRES } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

export default function Store() {
  const { purchases, purchaseBook, user } = useApp()
  const [search, setSearch]     = useState('')
  const [level,  setLevel]      = useState('All')
  const [genre,  setGenre]      = useState('All')
  const [sort,   setSort]       = useState('popular')
  const [preview, setPreview]   = useState(null)
  const [buying,  setBuying]    = useState(null)
  const [bought,  setBought]    = useState(null)

  const filtered = useMemo(() => {
    let list = STORE_BOOKS.filter(b => {
      if (search && !b.title.toLowerCase().includes(search.toLowerCase()) &&
          !b.author.toLowerCase().includes(search.toLowerCase())) return false
      if (level !== 'All' && b.level !== level) return false
      if (genre !== 'All' && b.genre !== genre) return false
      return true
    })
    if (sort === 'popular') list = [...list].sort((a,b) => b.sales - a.sales)
    if (sort === 'price_asc') list = [...list].sort((a,b) => a.price - b.price)
    if (sort === 'price_desc') list = [...list].sort((a,b) => b.price - a.price)
    if (sort === 'rating') list = [...list].sort((a,b) => b.rating - a.rating)
    return list
  }, [search, level, genre, sort])

  function handleBuy(book) {
    setBuying(book)
  }

  function confirmBuy(book) {
    purchaseBook(book)
    setBuying(null)
    setBought(book)
    setTimeout(() => setBought(null), 4000)
  }

  return (
    <div>
      {/* Hero */}
      <div style={hero}>
        <div style={{ fontSize: 48 }}>📚</div>
        <h1 style={{ margin: '8px 0 4px', color: 'var(--ink)' }}>EchoVerse Bookstore</h1>
        <p style={{ color: 'var(--muted)', margin: 0 }}>Buy books from independent writers. Read in-app, lend to friends, read aloud together.</p>
      </div>

      {/* Purchase success toast */}
      {bought && (
        <div style={toast}>
          ✓ "{bought.title}" added to <Link to="/mybooks" style={{ color: 'white', fontWeight: 'bold' }}>My Books</Link>!
        </div>
      )}

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
        <input placeholder="Search titles or authors…" value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ flex: 2, minWidth: 180, margin: 0 }} />
        <select value={sort} onChange={e => setSort(e.target.value)} style={{ flex: 1, minWidth: 130, margin: 0 }}>
          <option value="popular">Most popular</option>
          <option value="rating">Highest rated</option>
          <option value="price_asc">Price: low to high</option>
          <option value="price_desc">Price: high to low</option>
        </select>
      </div>
      <div className="pill-row" style={{ marginBottom: 6 }}>
        {['All', ...LEVELS].map(l => (
          <span key={l} className={`pill ${level === l ? 'active' : ''}`} onClick={() => setLevel(l)}>{l}</span>
        ))}
      </div>
      <div className="pill-row" style={{ marginBottom: 16 }}>
        {['All', ...GENRES].map(g => (
          <span key={g} className={`pill ${genre === g ? 'active' : ''}`} onClick={() => setGenre(g)}>{g}</span>
        ))}
      </div>

      {/* Book grid */}
      <div className="grid">
        {filtered.map(book => {
          const owned = !!purchases[book.id]
          return (
            <div className="card" key={book.id} style={{ display: 'flex', flexDirection: 'column' }}>
              {/* Cover area */}
              <div style={{ background: 'var(--accent-soft)', borderRadius: 8, padding: '20px 0', textAlign: 'center', marginBottom: 12, fontSize: 52 }}>
                {book.coverEmoji}
              </div>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 6 }}>
                <span className="tag">{book.level}</span>
                <span className="tag">{book.genre}</span>
                <span className="tag">{book.format}</span>
                {book.lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable</span>}
              </div>
              <h3 style={{ margin: '0 0 2px' }}>{book.title}</h3>
              <Link to={`/writers/${book.authorId}`} style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 6, display: 'block' }}>
                {book.authorAvatar} {book.author}
              </Link>
              <p style={{ fontSize: 13, flex: 1 }}>{book.description}</p>

              {/* Stats */}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--muted)', margin: '8px 0' }}>
                <span>⭐ {book.rating} ({book.reviewCount})</span>
                <span>{book.pages} pages · {book.chapters} chapters</span>
                <span>{book.sales} sold</span>
              </div>

              {/* Price + CTA */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                <span style={{ fontSize: 20, fontWeight: 'bold', color: 'var(--accent)' }}>
                  ${book.price.toFixed(2)}
                </span>
                <div style={{ flex: 1 }} />
                <button className="btn ghost" onClick={() => setPreview(book)}>Preview</button>
                {owned
                  ? <Link to="/mybooks"><button className="btn secondary">In My Books ✓</button></Link>
                  : <button className="btn" onClick={() => handleBuy(book)}>Buy now</button>
                }
              </div>
            </div>
          )
        })}
      </div>

      {/* Preview modal */}
      {preview && (
        <div style={overlayStyle} onClick={() => setPreview(null)}>
          <div style={modalStyle} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 40 }}>{preview.coverEmoji}</div>
                <h2 style={{ margin: '6px 0 2px' }}>{preview.title}</h2>
                <div style={{ fontSize: 13, color: 'var(--muted)' }}>{preview.authorAvatar} {preview.author}</div>
              </div>
              <button className="btn ghost" onClick={() => setPreview(null)}>✕</button>
            </div>
            <div style={{ background: 'var(--accent-soft)', borderRadius: 8, padding: 16, marginBottom: 16, fontStyle: 'italic', lineHeight: 1.8, fontSize: 15 }}>
              "{preview.preview}"
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8, fontStyle: 'normal' }}>— excerpt from page 1</div>
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
              {(preview.tags || []).map(t => <span key={t} className="tag">{t}</span>)}
              {preview.lendable && <span className="tag" style={{ background: '#e8f5e9', color: '#3f6b4a' }}>🤝 Lendable to friends (up to {preview.lendDays} days)</span>}
            </div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span style={{ fontSize: 22, fontWeight: 'bold', color: 'var(--accent)' }}>${preview.price.toFixed(2)}</span>
              <div style={{ flex: 1 }} />
              {purchases[preview.id]
                ? <Link to="/mybooks"><button className="btn secondary">In My Books ✓</button></Link>
                : <button className="btn" onClick={() => { handleBuy(preview); setPreview(null) }}>Buy now</button>
              }
            </div>
          </div>
        </div>
      )}

      {/* Buy confirmation modal */}
      {buying && (
        <div style={overlayStyle}>
          <div style={{ ...modalStyle, maxWidth: 360 }}>
            <div style={{ textAlign: 'center', marginBottom: 16 }}>
              <div style={{ fontSize: 48 }}>{buying.coverEmoji}</div>
              <h2 style={{ margin: '8px 0 4px' }}>Confirm purchase</h2>
              <p style={{ color: 'var(--muted)', fontSize: 13 }}>{buying.title}</p>
              <div style={{ fontSize: 28, fontWeight: 'bold', color: 'var(--accent)', margin: '12px 0' }}>
                ${buying.price.toFixed(2)}
              </div>
              <p style={{ fontSize: 12, color: 'var(--muted)' }}>
                Includes: {buying.format}
                {buying.lendable && ` · Can be lent to friends for up to ${buying.lendDays} day${buying.lendDays > 1 ? 's' : ''}`}
              </p>
            </div>
            <div style={{ background: 'var(--accent-soft)', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span>{buying.title}</span><span>${buying.price.toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
                <span>Total</span><span>${buying.price.toFixed(2)}</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn ghost" onClick={() => setBuying(null)} style={{ flex: 1 }}>Cancel</button>
              <button className="btn" onClick={() => confirmBuy(buying)} style={{ flex: 2 }}>
                Confirm & Pay ${buying.price.toFixed(2)}
              </button>
            </div>
            <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--muted)', marginTop: 10 }}>
              Demo — no real payment. Connect Stripe or Paystack in production.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

const hero = { background: 'var(--accent-soft)', borderRadius: 12, padding: '24px 20px', textAlign: 'center', marginBottom: 24 }
const toast = { position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', background: 'var(--good)', color: 'white', padding: '12px 20px', borderRadius: 30, zIndex: 300, fontSize: 14, boxShadow: '0 4px 12px rgba(0,0,0,0.2)', whiteSpace: 'nowrap' }
const overlayStyle = { position: 'fixed', inset: 0, background: 'rgba(43,36,24,0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }
const modalStyle = { background: 'var(--paper)', borderRadius: 16, padding: '24px', maxWidth: 500, width: '92%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 12px 40px rgba(0,0,0,0.3)' }
