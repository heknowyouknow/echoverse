import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { STORY_LIBRARY, LEVELS, GENRES } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'

export default function Explore() {
  const { user } = useApp()
  const [search, setSearch] = useState('')
  const [level, setLevel] = useState(user?.level || 'All')
  const [genre, setGenre] = useState('All')
  const [charFilter, setCharFilter] = useState(0)

  const filtered = useMemo(() => {
    return STORY_LIBRARY.filter(s => {
      if (search && !s.title.toLowerCase().includes(search.toLowerCase()) && !s.description.toLowerCase().includes(search.toLowerCase())) return false
      if (level !== 'All' && s.level !== level) return false
      if (genre !== 'All' && s.genre !== genre) return false
      if (charFilter > 0 && !s.characterOptions.includes(charFilter)) return false
      return true
    })
  }, [search, level, genre, charFilter])

  return (
    <div>
      <h1>Explore</h1>

      <input
        placeholder="Search stories, poems…"
        value={search}
        onChange={e => setSearch(e.target.value)}
        style={{ marginBottom: 16, fontSize: 15 }}
      />

      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 20 }}>
        <div>
          <label>Level</label>
          <div className="pill-row">
            {['All', ...LEVELS].map(l => (
              <span key={l} className={`pill ${level === l ? 'active' : ''}`} onClick={() => setLevel(l)}>{l}</span>
            ))}
          </div>
        </div>
        <div>
          <label>Genre</label>
          <div className="pill-row">
            {['All', ...GENRES].map(g => (
              <span key={g} className={`pill ${genre === g ? 'active' : ''}`} onClick={() => setGenre(g)}>{g}</span>
            ))}
          </div>
        </div>
        <div>
          <label>Characters</label>
          <div className="pill-row">
            {[0, 2, 3, 4, 5].map(n => (
              <span key={n} className={`pill ${charFilter === n ? 'active' : ''}`} onClick={() => setCharFilter(n)}>
                {n === 0 ? 'Any' : `${n}`}
              </span>
            ))}
          </div>
        </div>
      </div>

      {filtered.length === 0 && (
        <div className="card" style={{ textAlign: 'center', color: 'var(--muted)' }}>
          No stories matched. Try a different filter.
        </div>
      )}

      <div className="grid">
        {filtered.map(s => (
          <StoryCard key={s.id} story={s} />
        ))}
      </div>
    </div>
  )
}

function StoryCard({ story }) {
  return (
    <div className="card">
      <div style={{ fontSize: 36, marginBottom: 6 }}>{story.coverEmoji}</div>
      <span className="tag">{story.level}</span>
      <span className="tag">{story.genre}</span>
      <span className="tag">{story.source === 'AI-generated' ? '✨ AI' : '📖 Published'}</span>
      <h3 style={{ margin: '8px 0 4px' }}>{story.title}</h3>
      {story.author && <div style={{ fontSize: 12, color: 'var(--muted)' }}>by {story.author}</div>}
      <p style={{ fontSize: 13 }}>{story.description}</p>
      <div className="pill-row">
        {story.characterOptions.map(n => (
          <span key={n} className="pill" style={{ fontSize: 12 }}>{n} characters</span>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
        <Link to={`/read/${story.id}`}><button className="btn">Read now</button></Link>
        <Link to="/create" state={{ storyId: story.id }}><button className="btn secondary">Request partners</button></Link>
      </div>
    </div>
  )
}
