import { useState, useEffect } from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function Settings() {
  const { user, setUser, darkMode, setDarkMode, ttsVoiceIndex, setTtsVoiceIndex } = useApp()
  const [voices, setVoices] = useState([])
  const [defaultFontSize, setDefaultFontSize] = useState(18)
  const [notifPartners, setNotifPartners] = useState(true)
  const [notifBooks, setNotifBooks] = useState(true)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    function loadVoices() {
      const v = window.speechSynthesis?.getVoices() || []
      setVoices(v)
    }
    loadVoices()
    window.speechSynthesis?.addEventListener('voiceschanged', loadVoices)
    return () => window.speechSynthesis?.removeEventListener('voiceschanged', loadVoices)
  }, [])

  function previewVoice() {
    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance('The market at Kumasi woke before the sun.')
    if (voices[ttsVoiceIndex]) u.voice = voices[ttsVoiceIndex]
    u.rate = 0.9
    window.speechSynthesis.speak(u)
  }

  function save() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div>
      <h1>Settings</h1>

      {/* Appearance */}
      <Section title="🎨 Appearance">
        <ToggleRow
          label="Dark mode"
          subLabel="Switch to a dark paper-ink theme"
          value={darkMode}
          onChange={setDarkMode}
        />
        <div style={{ marginTop: 12 }}>
          <label>Default reading font size</label>
          <div className="pill-row" style={{ marginTop: 6 }}>
            {[14, 16, 18, 20, 24].map(s => (
              <span
                key={s}
                className={`pill ${defaultFontSize === s ? 'active' : ''}`}
                onClick={() => setDefaultFontSize(s)}
                style={{ fontSize: s * 0.7 }}
              >
                Aa ({s}px)
              </span>
            ))}
          </div>
        </div>
      </Section>

      {/* Text-to-speech */}
      <Section title="🔊 Read-aloud (text-to-speech)">
        <label>Reading voice</label>
        {voices.length === 0 && <p style={{ color: 'var(--muted)', fontSize: 13 }}>No TTS voices available in this browser.</p>}
        {voices.length > 0 && (
          <>
            <select value={ttsVoiceIndex} onChange={e => setTtsVoiceIndex(Number(e.target.value))}>
              {voices.map((v, i) => (
                <option key={i} value={i}>{v.name} ({v.lang})</option>
              ))}
            </select>
            <button className="btn secondary" onClick={previewVoice} style={{ marginTop: 4 }}>
              🔊 Preview voice
            </button>
          </>
        )}
      </Section>

      {/* Notifications */}
      <Section title="🔔 Notifications">
        <ToggleRow label="Partner requests" subLabel="Someone wants to join your reading" value={notifPartners} onChange={setNotifPartners} />
        <ToggleRow label="Book updates" subLabel="Writers you follow upload new content" value={notifBooks} onChange={setNotifBooks} />
      </Section>

      {/* Profile */}
      {user && (
        <Section title="👤 Profile">
          <label>Display name</label>
          <input
            value={user.name}
            onChange={e => setUser(u => ({ ...u, name: e.target.value }))}
          />
          <label>Reading level</label>
          <select value={user.level} onChange={e => setUser(u => ({ ...u, level: e.target.value }))}>
            {['Primary', 'Junior High', 'Senior High', 'University'].map(l => (
              <option key={l}>{l}</option>
            ))}
          </select>
        </Section>
      )}

      <button className="btn" onClick={save} style={{ marginTop: 8 }}>
        {saved ? '✓ Saved!' : 'Save settings'}
      </button>
    </div>
  )
}

function Section({ title, children }) {
  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <h3 style={{ marginTop: 0, marginBottom: 14, borderBottom: '1px solid var(--accent-soft)', paddingBottom: 8 }}>{title}</h3>
      {children}
    </div>
  )
}

function ToggleRow({ label, subLabel, value, onChange }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--accent-soft)' }}>
      <div>
        <div style={{ fontWeight: 'bold', fontSize: 14 }}>{label}</div>
        {subLabel && <div style={{ fontSize: 12, color: 'var(--muted)' }}>{subLabel}</div>}
      </div>
      <div
        onClick={() => onChange(!value)}
        style={{
          width: 44, height: 24, borderRadius: 999, cursor: 'pointer',
          background: value ? 'var(--accent)' : 'var(--accent-soft)',
          position: 'relative', transition: 'background 0.2s', flexShrink: 0
        }}
      >
        <div style={{
          position: 'absolute', top: 3, left: value ? 23 : 3,
          width: 18, height: 18, borderRadius: '50%',
          background: 'white', transition: 'left 0.2s',
          boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
        }} />
      </div>
    </div>
  )
}
