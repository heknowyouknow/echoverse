import { useParams, Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { READING_ROOMS, STORY_LIBRARY } from '../data/mockData.js'
import { useApp } from '../context/AppContext.jsx'
import CallBar from '../components/CallBar.jsx'

export default function RoomReading() {
  const { id } = useParams()
  const { user, joinRoom, addNotification } = useApp()
  const [room, setRoom] = useState(() => READING_ROOMS.find(r => r.id === id))
  const story = room ? STORY_LIBRARY.find(s => s.id === room.storyId) : null
  const [myCharacter, setMyCharacter] = useState(null)
  const [requested, setRequested] = useState(false)
  const [callJoined, setCallJoined] = useState(false)
  const [currentLine, setCurrentLine] = useState(null)
  const [fontSize, setFontSize] = useState(18)
  const [speaking, setSpeaking] = useState(false)

  useEffect(() => { if (room) joinRoom(room) }, [room])

  if (!room) return (
    <div className="card">
      Room not found. <Link to="/rooms">Browse rooms</Link>.
    </div>
  )

  const filledEntries = Object.entries(room.charactersFilled)
  const openChars = room.charactersNeeded.filter(c => !room.charactersFilled[c])

  function claimCharacter(char) {
    if (!user) return
    setRoom(r => ({
      ...r,
      charactersFilled: { ...r.charactersFilled, [char]: user.name }
    }))
    setMyCharacter(char)
    setCallJoined(true)
    addNotification({
      type: 'partner_request',
      from: user.name,
      message: `joined the room as ${char} in "${room.title}"`,
      roomId: room.id
    })
  }

  function requestPartner() {
    setRequested(true)
    addNotification({
      type: 'partner_request',
      from: 'System',
      message: `A reader was requested for ${openChars.join(', ')} in "${room.title}"`,
      roomId: room.id
    })
    setTimeout(() => {
      setRoom(r => {
        const firstOpen = r.charactersNeeded.find(c => !r.charactersFilled[c])
        if (!firstOpen) return r
        return { ...r, charactersFilled: { ...r.charactersFilled, [firstOpen]: 'Invited Reader' } }
      })
    }, 2500)
  }

  function speakLine(line) {
    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(line)
    u.rate = 0.88
    u.onstart = () => setSpeaking(true)
    u.onend = () => setSpeaking(false)
    window.speechSynthesis.speak(u)
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
        <span style={{ fontSize: 32 }}>{story?.coverEmoji || '📖'}</span>
        <div>
          <h1 style={{ margin: 0 }}>{room.title}</h1>
          <span className="tag">{room.level}</span>
          <span style={{ fontSize: 12, color: 'var(--muted)' }}>Hosted by {room.hostAvatar} {room.host}</span>
        </div>
      </div>

      {/* Character roster */}
      <div className="card">
        <h3 style={{ marginTop: 0 }}>Character roster</h3>
        {room.charactersNeeded.map(c => {
          const who = room.charactersFilled[c]
          const isMe = who === user?.name || (myCharacter === c)
          return (
            <div className="char-slot" key={c}>
              <span><b>{c}</b></span>
              {who
                ? <span className="status-filled">{who}{isMe ? ' (you)' : ''}</span>
                : (
                  <span>
                    <span className="status-open">needs a reader · </span>
                    {!myCharacter && (
                      <button className="btn" style={{ padding: '3px 10px', fontSize: 12 }} onClick={() => claimCharacter(c)}>
                        Take this part
                      </button>
                    )}
                  </span>
                )
              }
            </div>
          )
        })}
        <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {openChars.length > 0 && (
            <button className="btn secondary" disabled={requested} onClick={requestPartner}>
              {requested ? 'Request sent… waiting' : `Request ${openChars.length} available reader(s)`}
            </button>
          )}
          {!callJoined && myCharacter && (
            <button className="btn" onClick={() => setCallJoined(true)}>🎙️ Join voice call</button>
          )}
        </div>
      </div>

      {/* Controls bar — only shows once character claimed */}
      {myCharacter && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 13, color: 'var(--muted)' }}>You: <strong style={{ color: 'var(--accent)' }}>{myCharacter}</strong></span>
          <button className="btn ghost" onClick={() => setFontSize(f => Math.max(14, f - 2))}>A−</button>
          <button className="btn ghost" onClick={() => setFontSize(f => Math.min(28, f + 2))}>A+</button>
          {speaking
            ? <button className="btn secondary" onClick={() => window.speechSynthesis?.cancel()}>⏹ Stop</button>
            : null
          }
        </div>
      )}

      {/* Reading screen - the key design principle:
          this block occupies the main content column and has plenty of right-side
          margin so the fixed CallBar (bottom-right) never overlaps text. */}
      {story && (
        <div className="reading-screen" style={{ fontSize, paddingRight: callJoined ? 240 : 28 }}>
          {story.script.map((line, i) => {
            const isMine = line.character === myCharacter
            const isActive = i === currentLine
            return (
              <div
                key={i}
                className="character-line"
                onClick={() => { setCurrentLine(i); speakLine(`${line.character}. ${line.line}`) }}
                style={{
                  padding: '6px 10px',
                  borderRadius: 6,
                  background: isActive ? '#fff4ec' : 'transparent',
                  borderLeft: isMine ? '3px solid var(--accent)' : '3px solid transparent',
                  opacity: myCharacter && !isMine ? 0.6 : 1,
                  cursor: 'pointer',
                  transition: 'background 0.15s, opacity 0.15s'
                }}
              >
                <b style={{ color: isMine ? 'var(--accent)' : 'var(--ink)' }}>{line.character}:</b>{' '}
                {line.line}
              </div>
            )
          })}
        </div>
      )}

      {/* Call bar floats in the corner — does not lay over the text column */}
      {callJoined && (
        <CallBar
          roomTitle={room.title}
          participants={filledEntries.map(([char, who]) => `${who} (${char})`)}
        />
      )}
    </div>
  )
}
