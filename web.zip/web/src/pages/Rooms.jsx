import { useState } from 'react'
import { Link } from 'react-router-dom'
import { READING_ROOMS, LEVELS } from '../data/mockData.js'

export default function Rooms() {
  const [levelFilter, setLevelFilter] = useState('All')

  const filtered = READING_ROOMS.filter(r => levelFilter === 'All' || r.level === levelFilter)

  return (
    <div>
      <h1>Reading Rooms</h1>
      <p style={{ color: 'var(--muted)' }}>Open rooms looking for reading partners. The live call floats in a small bar so it never covers the text.</p>

      <div className="pill-row" style={{ marginBottom: 16 }}>
        {['All', ...LEVELS].map(l => (
          <span key={l} className={`pill ${levelFilter === l ? 'active' : ''}`} onClick={() => setLevelFilter(l)}>{l}</span>
        ))}
      </div>

      {filtered.map(r => {
        const openChars = r.charactersNeeded.filter(c => !r.charactersFilled[c])
        const filledChars = Object.entries(r.charactersFilled)
        return (
          <div className="card" key={r.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <span className="tag">{r.level}</span>
                <span className="status-open" style={{ marginLeft: 8 }}>● open · {openChars.length} part(s) free</span>
                <h3 style={{ margin: '6px 0 2px' }}>{r.title}</h3>
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 6 }}>
                  Hosted by {r.hostAvatar} {r.host}
                </div>
                <p style={{ fontSize: 13, margin: '4px 0 10px' }}>{r.description}</p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, marginBottom: 10 }}>
              {r.charactersNeeded.map(c => {
                const who = r.charactersFilled[c]
                return (
                  <div className="char-slot" key={c} style={{ gridColumn: 'span 1' }}>
                    <span style={{ fontWeight: 'bold', fontSize: 13 }}>{c}</span>
                    <span className={who ? 'status-filled' : 'status-open'}>{who || 'open'}</span>
                  </div>
                )
              })}
            </div>

            <Link to={`/rooms/${r.id}`}>
              <button className="btn">{openChars.length > 0 ? `Join as a reader →` : 'Open room →'}</button>
            </Link>
          </div>
        )
      })}

      <div className="card" style={{ background: 'var(--accent-soft)', border: 'none', marginTop: 8 }}>
        <h3 style={{ margin: '0 0 6px' }}>Don't see what you need?</h3>
        <p style={{ fontSize: 13, margin: '0 0 10px' }}>Request a story and build your own room with the characters you want.</p>
        <Link to="/create"><button className="btn">Request a story →</button></Link>
      </div>
    </div>
  )
}
