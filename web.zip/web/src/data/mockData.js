export const LEVELS = ['Primary', 'Junior High', 'Senior High', 'University']
export const GENRES = ['Poetry', 'Folktale', 'Drama', 'Novel Excerpt', 'Call & Response', 'Spoken Word']

// ── Stories / Poems ────────────────────────────────────────────────────────
export const STORY_LIBRARY = [
  {
    id: 's1',
    title: 'The Lantern of Kumasi',
    source: 'AI-generated',
    genre: 'Folktale',
    level: 'Junior High',
    characterOptions: [2, 3, 4],
    description: 'A market-day mystery told through two traders and a curious child.',
    coverEmoji: '🏮',
    script: [
      { character: 'Narrator', line: 'The market at Kumasi woke before the sun. Stalls bristled like spines as traders spread cloth, spice, and memory.' },
      { character: 'Trader 1', line: 'Fresh oranges! Sweet as the morning itself! Come, come!' },
      { character: 'Trader 2', line: 'You say that every day, Kofi. One day the morning will file a complaint.' },
      { character: 'Curious Child', line: 'Excuse me. Why does the lantern in the old market still burn when no one lights it?' },
      { character: 'Trader 1', line: '(goes quiet) That lantern… has burned since before my grandmother's time.' },
      { character: 'Narrator', line: 'The child picked up the lantern. The flame rose — not with heat, but with something older. Stories.' },
      { character: 'Trader 2', line: 'Put it down, child. Some light is not meant for young eyes.' },
      { character: 'Curious Child', line: 'But I can see you both inside it. You are in the story.' },
      { character: 'Narrator', line: 'And so they were. And so are we.' }
    ]
  },
  {
    id: 's2',
    title: 'Things Fall Apart — The Exile Speaks',
    source: 'Published book',
    author: 'Chinua Achebe (adapted excerpt)',
    genre: 'Novel Excerpt',
    level: 'University',
    characterOptions: [3, 4, 5],
    description: 'Multi-voice reading of the exile chapter — narrator, Okonkwo, Ekwefi, and Ezinma.',
    coverEmoji: '🌍',
    script: [
      { character: 'Narrator', line: 'Okonkwo did not return to Umuofia after seven years. He came back to a different clan — or perhaps a different man.' },
      { character: 'Okonkwo', line: 'The clan has fallen apart. Where are the warriors? Where are the men of title?' },
      { character: 'Ekwefi', line: 'They are still here, Okonkwo. They are simply… changed. As rivers change course.' },
      { character: 'Ezinma', line: 'Father. You cannot fight the sun because it rose in a new place.' },
      { character: 'Narrator', line: 'He looked at his daughter — the only one who understood him — and felt the world tighten around his chest like a vine.' },
      { character: 'Okonkwo', line: 'A man who cannot hold his clan is not a man. I was not born to watch.' },
      { character: 'Ekwefi', line: 'And I was not born to bury you.' }
    ]
  },
  {
    id: 's3',
    title: 'Two Frogs and a Drum',
    source: 'AI-generated',
    genre: 'Call & Response',
    level: 'Primary',
    characterOptions: [2, 3],
    description: 'A playful call-and-response folktale for young readers — perfect first voices.',
    coverEmoji: '🐸',
    script: [
      { character: 'Frog 1', line: 'Boom! Boom! I found a drum!' },
      { character: 'Frog 2', line: 'A drum? A drum? Let me come!' },
      { character: 'Narrator', line: 'The two frogs sat beside the drum. It was large. It was round. It smelled of old rain.' },
      { character: 'Frog 1', line: 'I will bang it in the morning!' },
      { character: 'Frog 2', line: 'I will bang it in the night!' },
      { character: 'Narrator', line: 'They banged and banged till the fireflies blinked and the moon covered her ears.' },
      { character: 'Frog 1', line: 'The drum is happy.' },
      { character: 'Frog 2', line: 'The drum is happy.' },
      { character: 'Frog 1', line: '…Are we happy?' },
      { character: 'Frog 2', line: 'I think we are tired. But yes. Happy.' }
    ]
  },
  {
    id: 's4',
    title: 'The River's Last Letter',
    source: 'AI-generated',
    genre: 'Spoken Word',
    level: 'Senior High',
    characterOptions: [2, 3],
    description: 'A two-voice spoken word poem about a river writing to the mountain it left behind.',
    coverEmoji: '🏔️',
    script: [
      { character: 'River', line: 'Dear Mountain, I have not forgotten you. I carry pieces of you everywhere I go — grey stone, red clay, the taste of your cold shadow.' },
      { character: 'Mountain', line: 'I watched you leave. Slow at first. Then all at once. The way grief works.' },
      { character: 'River', line: 'I did not leave. I was called. The sea called me by a name even I didn't know I had.' },
      { character: 'Mountain', line: 'And did you find what the sea promised?' },
      { character: 'River', line: 'I found more water. I found I was not special. I found I was enough.' },
      { character: 'Mountain', line: 'Then you found more than I ever could, rooted here, talking to clouds.' },
      { character: 'River', line: 'You were never rooted. You were planted. There's a difference.' },
      { character: 'Mountain', line: 'Come back and tell me that to my face.' },
      { character: 'River', line: 'I am always coming back. Every drop of rain that falls on you — that's me. Returning.' }
    ]
  },
  {
    id: 's5',
    title: 'Sunflower Arithmetic',
    source: 'AI-generated',
    genre: 'Poetry',
    level: 'Primary',
    characterOptions: [2],
    description: 'A number poem for two voices — one counts petals, one counts seeds.',
    coverEmoji: '🌻',
    script: [
      { character: 'Voice 1', line: 'One petal fell on a Tuesday.' },
      { character: 'Voice 2', line: 'One seed landed on a stone.' },
      { character: 'Voice 1', line: 'Two petals made a yellow road.' },
      { character: 'Voice 2', line: 'Two seeds — one alone, one not alone.' },
      { character: 'Voice 1', line: 'Three is the number of my fingers counting.' },
      { character: 'Voice 2', line: 'Three is the number of suns I've seen today.' },
      { character: 'Voice 1 & Voice 2', line: 'One flower. Many numbers. All of them true.' }
    ]
  }
]

// ── Reading Rooms ──────────────────────────────────────────────────────────
export const READING_ROOMS = [
  {
    id: 'r1',
    title: 'The Lantern of Kumasi — Live Reading',
    storyId: 's1',
    level: 'Junior High',
    host: 'Ama T.',
    hostAvatar: '🌺',
    charactersNeeded: ['Narrator', 'Trader 1', 'Trader 2', 'Curious Child'],
    charactersFilled: { 'Narrator': 'Ama T.' },
    status: 'open',
    startTime: null,
    description: 'Join us for a warm read of this lantern folktale. All welcome!'
  },
  {
    id: 'r2',
    title: 'Things Fall Apart — The Exile Speaks',
    storyId: 's2',
    level: 'University',
    host: 'Kwame O.',
    hostAvatar: '📖',
    charactersNeeded: ['Narrator', 'Okonkwo', 'Ekwefi', 'Ezinma'],
    charactersFilled: { 'Narrator': 'Kwame O.', 'Okonkwo': 'Yaw B.' },
    status: 'open',
    startTime: null,
    description: 'Achebe adaptation — thoughtful pace, senior readers preferred.'
  },
  {
    id: 'r3',
    title: 'River's Last Letter — Spoken Word',
    storyId: 's4',
    level: 'Senior High',
    host: 'Abena F.',
    hostAvatar: '🌙',
    charactersNeeded: ['River', 'Mountain'],
    charactersFilled: { 'River': 'Abena F.' },
    status: 'open',
    startTime: null,
    description: 'Looking for one more voice for the Mountain part. Expressiveness encouraged!'
  }
]

// ── Writer Books ───────────────────────────────────────────────────────────
export const WRITER_BOOKS = [
  {
    id: 'b1',
    title: 'Whispers Under the Baobab',
    writer: 'Efua Mensah',
    writerAvatar: '🌿',
    level: 'Senior High',
    genre: 'Poetry',
    format: 'PDF',
    price: 'Free',
    coverEmoji: '🌳',
    description: 'A coming-of-age verse novel set in a coastal Ghanaian town.',
    chapters: 12,
    fileUrl: null
  },
  {
    id: 'b2',
    title: 'Numbers That Sing',
    writer: 'Daniel K. Owusu',
    writerAvatar: '🎶',
    level: 'Primary',
    genre: 'Call & Response',
    format: 'Audio + Text',
    price: 'Free',
    coverEmoji: '🎵',
    description: 'Playful counting poems for early readers, with read-along audio.',
    chapters: 8,
    fileUrl: null
  },
  {
    id: 'b3',
    title: 'The Cartography of Loss',
    writer: 'Nana Akua Boateng',
    writerAvatar: '🕊️',
    level: 'University',
    genre: 'Spoken Word',
    format: 'PDF',
    price: 'Subscribe',
    coverEmoji: '🗺️',
    description: 'A debut collection mapping grief, migration, and memory through form.',
    chapters: 20,
    fileUrl: null
  }
]

// ── Mock async AI generation stub ─────────────────────────────────────────
export async function generateStory({ level, characterCount, theme, genre }) {
  await new Promise(r => setTimeout(r, 900))
  const chars = Array.from({ length: characterCount }, (_, i) =>
    i === 0 ? 'Narrator' : `Voice ${i}`
  )
  return {
    id: 'gen_' + Date.now(),
    title: `${theme || 'Echoes'} — a ${characterCount}-voice ${genre || 'story'}`,
    source: 'AI-generated',
    genre: genre || 'Poetry',
    level,
    coverEmoji: '✨',
    characterOptions: [characterCount],
    description: `A freshly generated ${characterCount}-character ${genre?.toLowerCase() || 'piece'} for ${level} readers.`,
    script: chars.map((c, i) => ({
      character: c,
      line: `(Mock line ${i + 1} for ${c} — connect the Claude API in generateStory() in mockData.js to produce real content.)`
    }))
  }
}

// ── Achievement definitions ────────────────────────────────────────────────
export const ACHIEVEMENTS = [
  { id: 'first_read',    emoji: '🌱', name: 'First Words',       desc: 'Completed your first story',         xp: 10  },
  { id: 'three_reads',   emoji: '📚', name: 'Bookworm',          desc: 'Completed 3 stories',                xp: 25  },
  { id: 'ten_reads',     emoji: '🔥', name: 'On Fire',           desc: 'Completed 10 stories',               xp: 75  },
  { id: 'first_room',    emoji: '🎭', name: 'Stage Fright Gone', desc: 'Joined your first reading room',     xp: 15  },
  { id: 'five_rooms',    emoji: '🌟', name: 'Scene Stealer',     desc: 'Joined 5 reading rooms',             xp: 50  },
  { id: 'hosted',        emoji: '🎬', name: 'Director',          desc: 'Hosted a reading room',              xp: 30  },
  { id: 'writer',        emoji: '🖊️',  name: 'Published',         desc: 'Uploaded your first book',          xp: 40  },
  { id: 'subscriber',    emoji: '💌', name: 'Patron',            desc: 'Subscribed to 3 books',              xp: 20  },
  { id: 'multi_level',   emoji: '🌈', name: 'Level Up',          desc: 'Read stories from 3 different levels', xp: 35 },
  { id: 'narrator',      emoji: '🗣️',  name: 'The Voice',         desc: 'Read the Narrator part 5 times',    xp: 30  },
  { id: 'partner',       emoji: '🤝', name: 'Team Player',       desc: 'Requested a reading partner',        xp: 10  },
  { id: 'streak_3',      emoji: '📅', name: '3-Day Streak',      desc: 'Read 3 days in a row',               xp: 20  },
  { id: 'primary_champ', emoji: '🏅', name: 'Primary Champion',  desc: 'Completed all Primary stories',      xp: 60  },
  { id: 'review_writer', emoji: '✍️',  name: 'Critic',            desc: 'Wrote your first review',            xp: 15  },
  { id: 'listener',      emoji: '🎧', name: 'Good Ear',          desc: 'Used TTS read-aloud 10 times',       xp: 20  },
]

// ── Character colour palette ───────────────────────────────────────────────
export const CHARACTER_COLORS = [
  '#a6442c', '#3f6b4a', '#1a5f8c', '#7a4a9e', '#b5762a', '#2c6b6b'
]

// ── Sample reviews ─────────────────────────────────────────────────────────
export const SAMPLE_REVIEWS = {
  b1: [
    { id: 'rv1', user: 'Kofi A.', avatar: '📖', rating: 5, text: 'The imagery in "Whispers Under the Baobab" is breathtaking. Every poem feels like a place you can visit.', date: '2026-07-10' },
    { id: 'rv2', user: 'Yaa P.',  avatar: '🌺', rating: 4, text: 'Beautiful language. Could use more dialogue-style poems for group reading.', date: '2026-07-14' }
  ],
  b2: [
    { id: 'rv3', user: 'Teacher Grace', avatar: '🌿', rating: 5, text: 'My Primary 3 class loves "Numbers That Sing". The call-and-response format is perfect.', date: '2026-07-20' }
  ],
  b3: []
}

// ── Writer profiles ────────────────────────────────────────────────────────
export const WRITERS = [
  {
    id: 'w1', name: 'Efua Mensah', avatar: '🌿',
    bio: 'Ghanaian poet and educator. She writes for young adults who are growing into their voices.',
    location: 'Accra, Ghana', bookIds: ['b1'],
    followers: 142, joined: '2025-11'
  },
  {
    id: 'w2', name: 'Daniel K. Owusu', avatar: '🎶',
    bio: 'Primary school teacher and children's author. Passionate about making reading joyful from day one.',
    location: 'Kumasi, Ghana', bookIds: ['b2'],
    followers: 87, joined: '2026-01'
  },
  {
    id: 'w3', name: 'Nana Akua Boateng', avatar: '🕊️',
    bio: 'Spoken word artist and literary critic. Her debut collection maps grief and migration through form.',
    location: 'London, UK', bookIds: ['b3'],
    followers: 310, joined: '2025-09'
  }
]

// ── Store / Marketplace books ──────────────────────────────────────────────
export const STORE_BOOKS = [
  {
    id: 'sb1',
    title: 'Whispers Under the Baobab',
    authorId: 'w1',
    author: 'Efua Mensah',
    authorAvatar: '🌿',
    coverEmoji: '🌳',
    level: 'Senior High',
    genre: 'Poetry',
    format: 'PDF + Audio',
    price: 4.99,
    currency: 'USD',
    description: 'A coming-of-age verse novel set in a coastal Ghanaian town. 12 chapters, 87 poems.',
    chapters: 12,
    pages: 134,
    preview: 'The baobab remembers everything. When I pressed my ear to its bark as a child, I heard the names of people the village had forgotten…',
    sales: 214,
    rating: 4.8,
    reviewCount: 41,
    publishedAt: '2025-11-03',
    tags: ['Ghana', 'coming-of-age', 'verse novel'],
    lendable: true,   // author allows lending
    lendDays: 7       // max days a lend can last
  },
  {
    id: 'sb2',
    title: 'Numbers That Sing',
    authorId: 'w2',
    author: 'Daniel K. Owusu',
    authorAvatar: '🎶',
    coverEmoji: '🎵',
    level: 'Primary',
    genre: 'Call & Response',
    format: 'PDF + Audio',
    price: 2.49,
    currency: 'USD',
    description: 'Playful counting poems for early readers with full audio read-along narrated by the author.',
    chapters: 8,
    pages: 56,
    preview: 'One seed fell on a stone. Two seeds held hands in the soil. Three seeds argued about who would grow tallest…',
    sales: 389,
    rating: 4.9,
    reviewCount: 76,
    publishedAt: '2026-01-15',
    tags: ['primary', 'counting', 'interactive'],
    lendable: true,
    lendDays: 3
  },
  {
    id: 'sb3',
    title: 'The Cartography of Loss',
    authorId: 'w3',
    author: 'Nana Akua Boateng',
    authorAvatar: '🕊️',
    coverEmoji: '🗺️',
    level: 'University',
    genre: 'Spoken Word',
    format: 'PDF',
    price: 6.99,
    currency: 'USD',
    description: 'A debut collection mapping grief, migration, and memory through form. Shortlisted for the Volta Prize.',
    chapters: 20,
    pages: 98,
    preview: 'I drew my mother's village from memory. Got the river wrong. Got the silence exactly right.',
    sales: 97,
    rating: 4.7,
    reviewCount: 22,
    publishedAt: '2025-09-20',
    tags: ['diaspora', 'grief', 'debut'],
    lendable: false,
    lendDays: 0
  },
  {
    id: 'sb4',
    title: 'Kente Threads: Stories in Pattern',
    authorId: 'w4',
    author: 'Yaw Darko',
    authorAvatar: '🧵',
    coverEmoji: '🎨',
    level: 'Junior High',
    genre: 'Folktale',
    format: 'PDF',
    price: 3.49,
    currency: 'USD',
    description: 'Seven folktales woven together like kente — each story a thread, each colour a meaning.',
    chapters: 7,
    pages: 88,
    preview: 'Every colour in kente has a name, and every name has a story. Gold is royalty, yes — but also the sweat of the weaver who stayed up all night.',
    sales: 156,
    rating: 4.6,
    reviewCount: 28,
    publishedAt: '2026-03-08',
    tags: ['folktale', 'culture', 'Ghana'],
    lendable: true,
    lendDays: 5
  }
]

// ── Author analytics (mock) ────────────────────────────────────────────────
export const AUTHOR_STATS = {
  w1: { totalSales: 214, totalRevenue: 856.43, monthlyRevenue: [42, 55, 61, 88, 97, 124], readers: 189, avgRating: 4.8, activeLends: 12 },
  w2: { totalSales: 389, totalRevenue: 776.10, monthlyRevenue: [80, 95, 110, 125, 140, 160], readers: 341, avgRating: 4.9, activeLends: 34 },
  w3: { totalSales: 97,  totalRevenue: 432.16, monthlyRevenue: [10, 14, 18, 20, 17, 22],  readers: 89,  avgRating: 4.7, activeLends: 0  },
  w4: { totalSales: 156, totalRevenue: 367.06, monthlyRevenue: [20, 28, 35, 40, 41, 36],  readers: 140, avgRating: 4.6, activeLends: 8  }
}

// ── Lend duration options ──────────────────────────────────────────────────
export const LEND_DURATIONS = [
  { label: '1 hour',  ms: 60 * 60 * 1000 },
  { label: '24 hours', ms: 24 * 60 * 60 * 1000 },
  { label: '3 days',  ms: 3 * 24 * 60 * 60 * 1000 },
  { label: '7 days',  ms: 7 * 24 * 60 * 60 * 1000 }
]

// ── Mock friends list ──────────────────────────────────────────────────────
export const MOCK_FRIENDS = [
  { id: 'f1', name: 'Ama Agyei',   avatar: '🌺', email: 'ama@example.com' },
  { id: 'f2', name: 'Kwame Osei',  avatar: '📖', email: 'kwame@example.com' },
  { id: 'f3', name: 'Yaw Boateng', avatar: '🌙', email: 'yaw@example.com' },
  { id: 'f4', name: 'Abena Frimpong', avatar: '🦋', email: 'abena@example.com' }
]
