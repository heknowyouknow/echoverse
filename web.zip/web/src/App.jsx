import { useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext.jsx'
import Navbar          from './components/Navbar.jsx'
import Onboarding      from './components/Onboarding.jsx'
import Home            from './pages/Home.jsx'
import Explore         from './pages/Explore.jsx'
import Rooms           from './pages/Rooms.jsx'
import RoomReading     from './pages/RoomReading.jsx'
import ReadStory       from './pages/ReadStory.jsx'
import CreateStoryRequest from './pages/CreateStoryRequest.jsx'
import Library         from './pages/Library.jsx'
import WriterUpload    from './pages/WriterUpload.jsx'
import Dashboard       from './pages/Dashboard.jsx'
import Achievements    from './pages/Achievements.jsx'
import Settings        from './pages/Settings.jsx'
import WriterProfile   from './pages/WriterProfile.jsx'
import BookDetail      from './pages/BookDetail.jsx'
import Store           from './pages/Store.jsx'
import MyBooks         from './pages/MyBooks.jsx'
import AuthorDashboard from './pages/AuthorDashboard.jsx'

function Shell() {
  const { user, darkMode } = useApp()
  useEffect(() => { document.body.classList.toggle('dark-mode', darkMode) }, [darkMode])

  return (
    <div className="app-shell">
      {!user && <Onboarding />}
      <Navbar />
      <div className="main">
        <Routes>
          <Route path="/"                  element={<Home />} />
          <Route path="/explore"           element={<Explore />} />
          <Route path="/rooms"             element={<Rooms />} />
          <Route path="/rooms/:id"         element={<RoomReading />} />
          <Route path="/read/:id"          element={<ReadStory />} />
          <Route path="/create"            element={<CreateStoryRequest />} />
          <Route path="/library"           element={<Library />} />
          <Route path="/upload"            element={<WriterUpload />} />
          <Route path="/dashboard"         element={<Dashboard />} />
          <Route path="/achievements"      element={<Achievements />} />
          <Route path="/settings"          element={<Settings />} />
          <Route path="/writers/:id"       element={<WriterProfile />} />
          <Route path="/books/:id"         element={<BookDetail />} />
          <Route path="/store"             element={<Store />} />
          <Route path="/mybooks"           element={<MyBooks />} />
          <Route path="/author-dashboard"  element={<AuthorDashboard />} />
        </Routes>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}
